# import tkinter as tk
# from tkinter import messagebox
#
# def on_button_click():
#     messagebox.showinfo("Info", "Button Clicked!")
#
# app = tk.Tk()
# app.title("Simple Tkinter App")
#
# label = tk.Label(app, text="Hello, Tkinter!")
# label.pack(pady=10)
#
# button = tk.Button(app, text="Click Me", command=on_button_click)
# button.pack(pady=5)
#
# app.mainloop()

#
# def custom_round(number, decimals):
#     """
#     Custom rounding function.
#
#     Parameters:
#     - number (float): The input decimal number.
#     - decimals (int): The number of decimal places to retain.
#
#     Returns:
#     - rounded_number (float): The rounded result according to the given rules.
#     """
#     # Convert the input number to a string to handle decimal places
#     num_str = f"{number:.{decimals + 10}f}"  # Include extra precision to handle rounding
#     integer_part, decimal_part = num_str.split('.')
#
#     # Extract the relevant decimal digits for rounding
#     rounding_digit = int(decimal_part[decimals]) if len(decimal_part) > decimals else 0
#     remainder_digits = decimal_part[decimals + 1:]
#     target_digit = int(decimal_part[decimals - 1]) if decimals > 0 else int(integer_part[-1])
#
#     if rounding_digit != 5:
#         # Standard rounding if the digit after the target is not 5
#         rounded_number = round(number, decimals)
#     else:
#         # When the rounding digit is 5
#         if any(d != '0' for d in remainder_digits):
#             # Case 1: If any digit after 5 is not zero, round up
#             rounded_number = round(number, decimals)
#         else:
#             # Case 2: All digits after 5 are zero
#             if target_digit % 2 == 0:
#                 # If the target digit before 5 is even, round down
#                 rounded_number = float(f"{integer_part}.{decimal_part[:decimals]}")
#             else:
#                 # If the target digit before 5 is odd, round up
#                 rounded_number = round(number, decimals)
#
#     return rounded_number
#
#
# # Example usage
# test_cases = [1.25325, 1.2500001, 3.2265000000000, 1.3500000]
# decimals_list = [2, 1, 3, 1]
# results = [custom_round(tc, d) for tc, d in zip(test_cases, decimals_list)]
# print(results)



def test0():
    print(round(1.835*1000000000000,2))
    print(1.835*1000000000000 == 1835*1000000000)

if __name__ == '__main__':
    test0()