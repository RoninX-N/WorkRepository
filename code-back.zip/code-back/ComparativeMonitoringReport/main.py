import tkinter as tk
from tkinter import messagebox
import InternalLogic

def on_button_click():
    # 获取输入框中的内容并赋值给变量
    form_type = entry1.get()
    SSD_address = entry2.get()
    InternalLogic.Start(form_type,SSD_address)
    messagebox.showinfo("Info", "Excel输出完成！")

if __name__ == '__main__':
    app = tk.Tk()
    app.title("一键计算CEMS数据")
    app.geometry("380x150")
    app.configure(bg='lightblue')

    label = tk.Label(app, text="终极无敌奥义之一键生成，提升您的效率，让您成为一只精英牛马！")
    label.pack(pady=10)

    # 创建一个框架用于水平排列输入框
    frame = tk.Frame(app)
    frame.pack(pady=10)

    # 创建输入框并设置默认值
    entry_var1 = tk.StringVar(value="原始在线数据表")
    entry1 = tk.Entry(frame, textvariable=entry_var1,justify='center')
    entry1.pack(side="right",pady=10)

    # 创建第二个输入框并设置默认值
    entry_var2 = tk.StringVar(value="D:\\OperationForProcess\\")
    entry2 = tk.Entry(frame, textvariable=entry_var2, justify='center')
    entry2.pack(side="left", padx=10)  # 同样使用 side="left"

    button = tk.Button(app, text="一键输出", command=on_button_click)
    button.pack(pady=5)

    app.mainloop()

