import pandas as pd
from openpyxl import load_workbook
import numpy as np
from datetime import datetime

CEMSDATAFILEPATH = "D:\\OperationForProcess\\数据.xlsx"
DATATEMPLATEFILEPATH = "D:\\OperationForProcess\\模板.xlsx"
DATAOUTPUTFILEPATH = "D:\\OperationForProcess\\结果.xlsx"

# 修约的逻辑------哈哈哈，白写了-------哈哈哈哈，还好没删，又没白写，又用上了
def SpecialAmend(number, decimal_0):
    temp = decimal_0 + 1
    decimal_point = 1
    while(temp>0):
        decimal_point = decimal_point / 10
        temp = temp - 1
    # python中整数任意大除法都不会丢失精度
    try:
        if int(number*100000000000000) % int(decimal_point*100000000000000) != 0:
            return round(number, decimal_0)
        else:
            pre = int(int(number*100000000000000) / int(decimal_point*100000000000000) / 10) % 10
            pivot = int(int(number*100000000000000) / int(decimal_point*100000000000000)) % 10
            # print(pre)
            # print(pivot)
            if pivot != 5:
                return round(number, decimal_0)
            else:

                if pre % 2 != 0:
                    # print(pre)
                    return round(number + 0.0001, decimal_0)
                else:
                    # print(pre)
                    if pre == 2 or pre == 4:
                        return round(number, decimal_0) - decimal_point * 10
                    else:
                        return round(number, decimal_0)
    except:
        return number

# 这个函数的功能是根据开始时间、结束时间、监测的数据项目来计算相关的均值并返回
def Selectdata(pretime,tailtime,cems_array,project):
    sum = 0
    count = 0
    # <editor-fold desc='筛选数据标志'>
    judge = 0
    if project == "颗粒物":
        judge = 1
    if project == "二氧化硫":
        judge = 2
    if project == "氮氧化物":
        judge = 3
    if project == "氧含量" or project == "氧气含量":
        judge = 4
    if project == "流速":
        judge = 5
    if project == "温度":
        judge = 6
    if project == "湿度":
        judge = 7
    # </editor-fold>

    for row in cems_array[1:]:
        try:
            if pretime <= (datetime.strptime(row[0], "%Y-%m-%d %H:%M:%S")).time() <= tailtime:
                try:
                    sum = sum + float(row[judge])
                except:
                    return "无数据"
                count = count + 1
            else:
                continue
        except:
            try:
                if pretime <= (datetime.strptime(str(row[0]), "%H:%M:%S")).time() <= tailtime:
                    try:
                        sum = sum + float(row[judge])
                    except:
                        return "无数据"
                    count = count + 1
                else:
                    continue
            except:
                return "没有填写时间或者时间格式不对"
    if count == 0:
        return "时间前后可能写反了"
    return sum/count

def Start():
    # 模板带格式读入
    datatemplate_workbook = load_workbook(DATATEMPLATEFILEPATH)
    datatemplate_sheet = datatemplate_workbook["比对报告数据模板"]
    # 在线数据读入
    total_cems_data_sheet = pd.read_excel(CEMSDATAFILEPATH,header=None)

    # <editor-fold desc='这一段负责将读入的数据规整位置，分清哪些数据在哪一列'>
    # 设置数据表表头
    cems_array = np.array([['时间','颗粒物','二氧化硫','氮氧化物','氧含量','流速','温度','湿度']])

    # 找到数据表的内容是从第几行开始
    start_row = 0
    for row in total_cems_data_sheet.iloc[0:].itertuples(index=False):
        if "时间" in str(row[0]):
            break
        start_row = start_row + 1
    print(start_row)

    # 表头排序整理
    headcolumn = 0

    time_head = 0
    partical = 0
    partical_wet = 0
    so2 = 0
    nox = 0
    o2 = 0
    vof = 0
    temperature = 0
    humidity = 0
    data_head = total_cems_data_sheet.iloc[start_row]
    for head in data_head:
        if "时间" in head:
            time_head = headcolumn
        if "烟尘" in head:
            if "烟尘(湿)" in head:
                partical_wet = headcolumn
            else:
                partical = headcolumn
        if "二氧化硫" in head or "SO2" in head or "so2" in head:
            so2 = headcolumn
        if "氮氧化物" in head or "NOX" in head or "nox" in head or "NOx" in head:
            nox = headcolumn
        if "氧含量" in head or "含氧量" in head or "氧气含量" in head:
            o2 = headcolumn
        if "流速" in head:
            vof = headcolumn
        if "温度" in head:
            temperature = headcolumn
        if "湿度" in head:
            humidity = headcolumn
        headcolumn = headcolumn + 1

    # 将对应数值提取到cems_array中
    for row in total_cems_data_sheet.iloc[start_row+1:].itertuples(index=False):
        newrow = [row[time_head],row[partical],row[so2],row[nox],row[o2],row[vof],row[temperature],row[humidity]]
        cems_array = np.vstack((cems_array,newrow))
    print(cems_array)
    # </editor-fold>

    # <editor-fold desc='调用函数生成数据'>

        # <editor-fold desc='定义数据结果值，为将来加入其他计算结果而使用'>
    partical_D4 = 0
    partical_D5 = 0
    partical_D6 = 0
    partical_D7 = 0
    partical_D8 = 0
    vof_H4 = 0
    vof_H5 = 0
    vof_H6 = 0
    vof_H7 = 0
    vof_H8 = 0
    temperature_L4 = 0
    temperature_L5 = 0
    temperature_L6 = 0
    temperature_L7 = 0
    temperature_L8 = 0
    humidity_P4 = 0
    humidity_P5 = 0
    humidity_P6 = 0
    humidity_P7 = 0
    humidity_P8 = 0
    o2_D12 = 0
    o2_D13 = 0
    o2_D14 = 0
    o2_D15 = 0
    o2_D16 = 0
    o2_D17 = 0
    o2_D18 = 0
    o2_D19 = 0
    o2_D20 = 0
    so2_H12 = 0
    so2_H13 = 0
    so2_H14 = 0
    so2_H15 = 0
    so2_H16 = 0
    so2_H17 = 0
    so2_H18 = 0
    so2_H19 = 0
    so2_H20 = 0
    nox_L12 = 0
    nox_L13 = 0
    nox_L14 = 0
    nox_L15 = 0
    nox_L16 = 0
    nox_L17 = 0
    nox_L18 = 0
    nox_L19 = 0
    nox_L20 = 0
        # </editor-fold>

        # <editor-fold desc='读数、调用函数计算相应值，并直接将结果写入指定单元格'>
    datatemplate_sheet['D4'] = SpecialAmend(Selectdata(datatemplate_sheet['B4'].value,datatemplate_sheet['C4'].value,cems_array,"颗粒物"),1)
    datatemplate_sheet['D5'] = SpecialAmend(Selectdata(datatemplate_sheet['B5'].value,datatemplate_sheet['C5'].value,cems_array,"颗粒物"),1)
    datatemplate_sheet['D6'] = SpecialAmend(Selectdata(datatemplate_sheet['B6'].value,datatemplate_sheet['C6'].value,cems_array,"颗粒物"),1)
    datatemplate_sheet['D7'] = SpecialAmend(Selectdata(datatemplate_sheet['B7'].value,datatemplate_sheet['C7'].value,cems_array,"颗粒物"),1)
    datatemplate_sheet['D8'] = SpecialAmend(Selectdata(datatemplate_sheet['B8'].value,datatemplate_sheet['C8'].value,cems_array,"颗粒物"),1)
    datatemplate_sheet['H4'] = SpecialAmend(Selectdata(datatemplate_sheet['F4'].value,datatemplate_sheet['G4'].value,cems_array,"流速"),2)
    datatemplate_sheet['H5'] = SpecialAmend(Selectdata(datatemplate_sheet['F5'].value,datatemplate_sheet['G5'].value,cems_array,"流速"),2)
    datatemplate_sheet['H6'] = SpecialAmend(Selectdata(datatemplate_sheet['F6'].value,datatemplate_sheet['G6'].value,cems_array,"流速"),2)
    datatemplate_sheet['H7'] = SpecialAmend(Selectdata(datatemplate_sheet['F7'].value,datatemplate_sheet['G7'].value,cems_array,"流速"),2)
    datatemplate_sheet['H8'] = SpecialAmend(Selectdata(datatemplate_sheet['F8'].value,datatemplate_sheet['G8'].value,cems_array,"流速"),2)
    datatemplate_sheet['L4'] = SpecialAmend(Selectdata(datatemplate_sheet['J4'].value,datatemplate_sheet['K4'].value,cems_array,"温度"),1)
    datatemplate_sheet['L5'] = SpecialAmend(Selectdata(datatemplate_sheet['J5'].value,datatemplate_sheet['K5'].value,cems_array,"温度"),1)
    datatemplate_sheet['L6'] = SpecialAmend(Selectdata(datatemplate_sheet['J6'].value,datatemplate_sheet['K6'].value,cems_array,"温度"),1)
    datatemplate_sheet['L7'] = SpecialAmend(Selectdata(datatemplate_sheet['J7'].value,datatemplate_sheet['K7'].value,cems_array,"温度"),1)
    datatemplate_sheet['L8'] = SpecialAmend(Selectdata(datatemplate_sheet['J8'].value,datatemplate_sheet['K8'].value,cems_array,"温度"),1)
    datatemplate_sheet['P4'] = SpecialAmend(Selectdata(datatemplate_sheet['N4'].value,datatemplate_sheet['O4'].value,cems_array,"湿度"),2)
    datatemplate_sheet['P5'] = SpecialAmend(Selectdata(datatemplate_sheet['N5'].value,datatemplate_sheet['O5'].value,cems_array,"湿度"),2)
    datatemplate_sheet['P6'] = SpecialAmend(Selectdata(datatemplate_sheet['N6'].value,datatemplate_sheet['O6'].value,cems_array,"湿度"),2)
    datatemplate_sheet['P7'] = SpecialAmend(Selectdata(datatemplate_sheet['N7'].value,datatemplate_sheet['O7'].value,cems_array,"湿度"),2)
    datatemplate_sheet['P8'] = SpecialAmend(Selectdata(datatemplate_sheet['N8'].value,datatemplate_sheet['O8'].value,cems_array,"湿度"),2)
    datatemplate_sheet['D13'] = SpecialAmend(Selectdata(datatemplate_sheet['B13'].value,datatemplate_sheet['C13'].value,cems_array,"氧含量"),2)
    datatemplate_sheet['D14'] = SpecialAmend(Selectdata(datatemplate_sheet['B14'].value,datatemplate_sheet['C14'].value,cems_array,"氧含量"),2)
    datatemplate_sheet['D15'] = SpecialAmend(Selectdata(datatemplate_sheet['B15'].value,datatemplate_sheet['C15'].value,cems_array,"氧含量"),2)
    datatemplate_sheet['D16'] = SpecialAmend(Selectdata(datatemplate_sheet['B16'].value,datatemplate_sheet['C16'].value,cems_array,"氧含量"),2)
    datatemplate_sheet['D17'] = SpecialAmend(Selectdata(datatemplate_sheet['B17'].value,datatemplate_sheet['C17'].value,cems_array,"氧含量"),2)
    datatemplate_sheet['D18'] = SpecialAmend(Selectdata(datatemplate_sheet['B18'].value,datatemplate_sheet['C18'].value,cems_array,"氧含量"),2)
    datatemplate_sheet['D19'] = SpecialAmend(Selectdata(datatemplate_sheet['B19'].value,datatemplate_sheet['C19'].value,cems_array,"氧含量"),2)
    datatemplate_sheet['D20'] = SpecialAmend(Selectdata(datatemplate_sheet['B20'].value,datatemplate_sheet['C20'].value,cems_array,"氧含量"),2)
    datatemplate_sheet['D21'] = SpecialAmend(Selectdata(datatemplate_sheet['B21'].value,datatemplate_sheet['C21'].value,cems_array,"氧含量"),2)
    datatemplate_sheet['H13'] = SpecialAmend(Selectdata(datatemplate_sheet['F13'].value,datatemplate_sheet['G13'].value,cems_array,"二氧化硫"),1)
    datatemplate_sheet['H14'] = SpecialAmend(Selectdata(datatemplate_sheet['F14'].value,datatemplate_sheet['G14'].value,cems_array,"二氧化硫"),1)
    datatemplate_sheet['H15'] = SpecialAmend(Selectdata(datatemplate_sheet['F15'].value,datatemplate_sheet['G15'].value,cems_array,"二氧化硫"),1)
    datatemplate_sheet['H16'] = SpecialAmend(Selectdata(datatemplate_sheet['F16'].value,datatemplate_sheet['G16'].value,cems_array,"二氧化硫"),1)
    datatemplate_sheet['H17'] = SpecialAmend(Selectdata(datatemplate_sheet['F17'].value,datatemplate_sheet['G17'].value,cems_array,"二氧化硫"),1)
    datatemplate_sheet['H18'] = SpecialAmend(Selectdata(datatemplate_sheet['F18'].value,datatemplate_sheet['G18'].value,cems_array,"二氧化硫"),1)
    datatemplate_sheet['H19'] = SpecialAmend(Selectdata(datatemplate_sheet['F19'].value,datatemplate_sheet['G19'].value,cems_array,"二氧化硫"),1)
    datatemplate_sheet['H20'] = SpecialAmend(Selectdata(datatemplate_sheet['F20'].value,datatemplate_sheet['G20'].value,cems_array,"二氧化硫"),1)
    datatemplate_sheet['H21'] = SpecialAmend(Selectdata(datatemplate_sheet['F21'].value,datatemplate_sheet['G21'].value,cems_array,"二氧化硫"),1)
    datatemplate_sheet['L13'] = SpecialAmend(Selectdata(datatemplate_sheet['J13'].value,datatemplate_sheet['K13'].value,cems_array,"氮氧化物"),1)
    datatemplate_sheet['L14'] = SpecialAmend(Selectdata(datatemplate_sheet['J14'].value,datatemplate_sheet['K14'].value,cems_array,"氮氧化物"),1)
    datatemplate_sheet['L15'] = SpecialAmend(Selectdata(datatemplate_sheet['J15'].value,datatemplate_sheet['K15'].value,cems_array,"氮氧化物"),1)
    datatemplate_sheet['L16'] = SpecialAmend(Selectdata(datatemplate_sheet['J16'].value,datatemplate_sheet['K16'].value,cems_array,"氮氧化物"),1)
    datatemplate_sheet['L17'] = SpecialAmend(Selectdata(datatemplate_sheet['J17'].value,datatemplate_sheet['K17'].value,cems_array,"氮氧化物"),1)
    datatemplate_sheet['L18'] = SpecialAmend(Selectdata(datatemplate_sheet['J18'].value,datatemplate_sheet['K18'].value,cems_array,"氮氧化物"),1)
    datatemplate_sheet['L19'] = SpecialAmend(Selectdata(datatemplate_sheet['J19'].value,datatemplate_sheet['K19'].value,cems_array,"氮氧化物"),1)
    datatemplate_sheet['L20'] = SpecialAmend(Selectdata(datatemplate_sheet['J20'].value,datatemplate_sheet['K20'].value,cems_array,"氮氧化物"),1)
    datatemplate_sheet['L21'] = SpecialAmend(Selectdata(datatemplate_sheet['J21'].value,datatemplate_sheet['K21'].value,cems_array,"氮氧化物"),1)

        # </editor-fold>

    # </editor-fold>

    datatemplate_workbook.save(DATAOUTPUTFILEPATH)

# 下面是测试主函数
def main():
    # start = time.perf_counter()
    # Start()
    # end = time.perf_counter()
    # print('Running time: %s Seconds'%(end-start))
    print(SpecialAmend(0.3558,1))
    pass

if __name__ == '__main__':
    main()
