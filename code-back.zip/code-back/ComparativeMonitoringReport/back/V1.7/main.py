import tkinter as tk
from tkinter import messagebox
import InternalLogic

def on_button_click():
    InternalLogic.Start()
    messagebox.showinfo("Info", "Excel输出完成！")

if __name__ == '__main__':
    app = tk.Tk()
    app.title("一键计算CEMS数据")
    app.geometry("300x100")
    app.configure(bg='lightblue')

    label = tk.Label(app, text="你好，小伙子（姑娘）^_^")
    label.pack(pady=10)

    button = tk.Button(app, text="一键输出", command=on_button_click)
    button.pack(pady=5)

    app.mainloop()

