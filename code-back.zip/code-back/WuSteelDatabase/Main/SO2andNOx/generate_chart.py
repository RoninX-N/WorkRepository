import pandas as pd
from pyecharts.charts import Line
from pyecharts import options as opts
from datetime import datetime

# 读取 Excel 文件
# 1. 读取Excel文件中的两个Sheet
df1 = pd.read_excel("D:\\各工序日排放量.xlsx", sheet_name='二氧化硫',skiprows=1)  # 替换为实际的Sheet名称，从第三行开始读数据
df2 = pd.read_excel("D:\\各工序日排放量.xlsx", sheet_name='氮氧化物',skiprows=1)

def format_date(date_str):
    try:
        # 尝试转换 "YYYY-MM-DD HH:MM:SS" 格式
        return datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S").strftime("%m月%d日")
    except ValueError:
        # 如果已经是 "MM月DD日" 格式，直接返回
        return date_str

def generate_chart():
    # <editor-fold desc='读取表中数据赋值给各个数组'>
    time = df1.iloc[:, 0].astype(str).tolist()
    print(type(time[0]))
    print(time[0])
    # print(datetime.strptime(time[0], "%Y-%m-%d %H:%M:%S").strftime("%m月%d日"))
    # for i in time[0:]:
    #     temp = datetime.strptime(time[0], "%Y-%m-%d %H:%M:%S").strftime("%m月%d日")
    #     time[i] = temp
    # formatted_dates = [datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S").strftime("%m月%d日") for date_str in time]
    formatted_dates = [format_date(date_str) for date_str in time]

    SO2_liantie = df1.iloc[:, 1].tolist()
    SO2_tiaocai = df1.iloc[:, 2].tolist()
    SO2_rezha = df1.iloc[:, 3].tolist()
    SO2_lengzha = df1.iloc[:, 4].tolist()
    SO2_nenghuan = df1.iloc[:, 5].tolist()
    SO2_jiaohua = df1.iloc[:, 6].tolist()
    SO2_sum = df1.iloc[:, 7].tolist()

    NOx_liantie = df2.iloc[:, 1].tolist()
    NOx_tiaocai = df2.iloc[:, 2].tolist()
    NOx_rezha = df2.iloc[:, 3].tolist()
    NOx_lengzha = df2.iloc[:, 4].tolist()
    NOx_nenghuan = df2.iloc[:, 5].tolist()
    NOx_jiaohua = df2.iloc[:, 6].tolist()
    NOx_sum = df2.iloc[:, 7].tolist()
    # </editor-fold>

    line_SO2 = (
        Line(init_opts=opts.InitOpts(width="1500px",height="650px"))
            .add_xaxis(formatted_dates)
            .add_yaxis(series_name="炼铁厂", y_axis=SO2_liantie, symbol="emptyCircle", is_smooth=True,
                       label_opts=opts.LabelOpts(is_show=False))
            .add_yaxis(series_name="条材厂", y_axis=SO2_tiaocai, symbol="emptyCircle", is_smooth=True,
                       label_opts=opts.LabelOpts(is_show=False))
            .add_yaxis(series_name="热轧厂", y_axis=SO2_rezha, symbol="emptyCircle", is_smooth=True,
                       label_opts=opts.LabelOpts(is_show=False))
            .add_yaxis(series_name="冷轧厂", y_axis=SO2_lengzha, symbol="emptyCircle", is_smooth=True,
                       label_opts=opts.LabelOpts(is_show=False))
            .add_yaxis(series_name="能环部", y_axis=SO2_nenghuan, symbol="emptyCircle", is_smooth=True,
                       label_opts=opts.LabelOpts(is_show=False))
            .add_yaxis(series_name="焦化公司", y_axis=SO2_jiaohua, symbol="emptyCircle", is_smooth=True,
                       label_opts=opts.LabelOpts(is_show=False))
            .add_yaxis(series_name="总排放量", y_axis=SO2_sum, symbol="emptyCircle", is_smooth=True,
                       label_opts=opts.LabelOpts(is_show=False))
            .set_global_opts(title_opts=opts.TitleOpts(title="武钢有限二氧化硫日排放量跟踪（吨）"),
                             toolbox_opts=opts.ToolboxOpts(pos_top="1%", is_show=True, feature=opts.ToolBoxFeatureOpts(
                                 save_as_image=opts.ToolBoxFeatureSaveAsImageOpts(background_color='white'))),
                             legend_opts=opts.LegendOpts(pos_top="8%"),
                             datazoom_opts=opts.DataZoomOpts(range_start=0, range_end=100), )
    )
    line_SO2.render("D:\\武钢有限二氧化硫日排放量跟踪曲线图.html")

    line_NOx = (
        Line(init_opts=opts.InitOpts(width="1500px", height="650px"))
            .add_xaxis(formatted_dates)
            .add_yaxis(series_name="炼铁厂", y_axis=NOx_liantie, symbol="emptyCircle", is_smooth=True,
                       label_opts=opts.LabelOpts(is_show=False))
            .add_yaxis(series_name="条材厂", y_axis=NOx_tiaocai, symbol="emptyCircle", is_smooth=True,
                       label_opts=opts.LabelOpts(is_show=False))
            .add_yaxis(series_name="热轧厂", y_axis=NOx_rezha, symbol="emptyCircle", is_smooth=True,
                       label_opts=opts.LabelOpts(is_show=False))
            .add_yaxis(series_name="冷轧厂", y_axis=NOx_lengzha, symbol="emptyCircle", is_smooth=True,
                       label_opts=opts.LabelOpts(is_show=False))
            .add_yaxis(series_name="能环部", y_axis=NOx_nenghuan, symbol="emptyCircle", is_smooth=True,
                       label_opts=opts.LabelOpts(is_show=False))
            .add_yaxis(series_name="焦化公司", y_axis=NOx_jiaohua, symbol="emptyCircle", is_smooth=True,
                       label_opts=opts.LabelOpts(is_show=False))
            .add_yaxis(series_name="总排放量", y_axis=NOx_sum, symbol="emptyCircle", is_smooth=True,
                       label_opts=opts.LabelOpts(is_show=False))
            .set_global_opts(title_opts=opts.TitleOpts(title="武钢有限氮氧化物日排放量跟踪（吨）"),
                             toolbox_opts=opts.ToolboxOpts(pos_top="1%", is_show=True, feature=opts.ToolBoxFeatureOpts(
                                 save_as_image=opts.ToolBoxFeatureSaveAsImageOpts(background_color='white'))),
                             legend_opts=opts.LegendOpts(pos_top="8%"),
                             datazoom_opts=opts.DataZoomOpts(range_start=0, range_end=100), )
    )
    line_NOx.render("D:\\武钢有限氮氧化物日排放量跟踪曲线图.html")

    # html_str_SO2 = line_SO2.render_embed()
    # html_str_NOx = line_NOx.render_embed()
    #
    # with open("chart_SO2.html", "w", encoding="utf-8") as f:
    #     f.write("<html><head><meta charset='utf-8'></head><body>")
    #     f.write(html_str_SO2)
    #     f.write("</body></html>")
    #
    # with open("chart_NOx.html", "w", encoding="utf-8") as f:
    #     f.write("<html><head><meta charset='utf-8'></head><body>")
    #     f.write(html_str_NOx)
    #     f.write("</body></html>")

if __name__ == '__main__':
    generate_chart()