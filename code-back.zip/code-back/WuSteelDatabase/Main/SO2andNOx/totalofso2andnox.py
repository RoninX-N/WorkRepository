import pandas as pd
import numpy as np

def Total(cems_array,flag,particle_array):
    total_SO2 = 0
    total_NOx = 0
    total_particle = 0
    for row in cems_array[1:]:
        total_SO2 += float(row[0]) * float(row[2]) * 3600
        total_NOx += float(row[1]) * float(row[2]) * 3600
    for row in particle_array[1:]:
        if row[2] != "DA204" and row[2] != "DA820":
            total_particle += float(row[0]) * float(row[1]) * 3600
    if flag == 1:
        return "全厂总的二氧化硫排放量：" + str('{:2f}'.format(total_SO2/1000000000)) + "t，氮氧化物排放量：" + str('{:2f}'.format(total_NOx/1000000000)) + "t"
    elif flag == 2:
        return str('{:2f}'.format(total_SO2/1000000000))
    elif flag == 3:
        return str('{:2f}'.format(total_NOx/1000000000))
    elif flag == 4:
        return str('{:2f}'.format(total_particle/1000000000))

def Wusteel(cems_array,flag,particle_array):
    total_SO2 = 0
    total_NOx = 0
    total_particle = 0
    for row in cems_array[1:]:
        if not "JH" in row[3]:
            total_SO2 += float(row[0]) * float(row[2]) * 3600
            total_NOx += float(row[1]) * float(row[2]) * 3600
    for row in particle_array[1:]:
        if not "JH" in row[2]:
            total_particle += float(row[0]) * float(row[1]) * 3600
    if flag == 1:
        return "武钢有限二氧化硫排放量：" + str('{:2f}'.format(total_SO2/1000000000)) + "t，氮氧化物排放量：" + str('{:2f}'.format(total_NOx/1000000000)) + "t"
    elif flag == 2:
        return str('{:2f}'.format(total_SO2/1000000000))
    elif flag == 3:
        return str('{:2f}'.format(total_NOx/1000000000))
    elif flag == 4:
        return str('{:2f}'.format(total_particle / 1000000000))

def JH(cems_array,flag,particle_array):
    total_SO2 = 0
    total_NOx = 0
    total_particle = 0
    for row in cems_array[1:]:
        if "JH" in row[3]:
            total_SO2 += float(row[0]) * float(row[2]) * 3600
            total_NOx += float(row[1]) * float(row[2]) * 3600
    for row in particle_array[1:]:
        if "JH" in row[2]:
            total_particle += float(row[0]) * float(row[1]) * 3600
    if flag == 1:
        return "焦化公司二氧化硫排放量：" + str('{:2f}'.format(total_SO2 / 1000000000)) + "t，氮氧化物排放量：" + str(
            '{:2f}'.format(total_NOx / 1000000000)) + "t"
    elif flag == 2:
        return str('{:2f}'.format(total_SO2 / 1000000000))
    elif flag == 3:
        return str('{:2f}'.format(total_NOx / 1000000000))
    elif flag == 4:
        return str('{:2f}'.format(total_particle / 1000000000))

def LT(cems_array,flag,particle_array):
    total_SO2 = 0
    total_NOx = 0
    total_particle = 0
    for row in cems_array[1:]:
        if row[4] == "炼铁厂" and "JH" not in row[3]:
            total_SO2 += float(row[0]) * float(row[2]) * 3600
            total_NOx += float(row[1]) * float(row[2]) * 3600
    for row in particle_array[1:]:
        if row[3] == "炼铁厂" and "JH" not in row[2]:
            total_particle += float(row[0]) * float(row[1]) * 3600
    if flag == 1:
        return "炼铁厂二氧化硫排放量：" + str('{:2f}'.format(total_SO2 / 1000000000)) + "t，氮氧化物排放量：" + str(
            '{:2f}'.format(total_NOx / 1000000000)) + "t"
    elif flag == 2:
        return str('{:2f}'.format(total_SO2 / 1000000000))
    elif flag == 3:
        return str('{:2f}'.format(total_NOx / 1000000000))
    elif flag == 4:
        return str('{:2f}'.format(total_particle / 1000000000))

def LG(cems_array,flag,particle_array):
    total_SO2 = 0
    total_NOx = 0
    total_particle = 0
    for row in cems_array[1:]:
        if row[4] == "炼钢厂":
            total_SO2 += float(row[0]) * float(row[2]) * 3600
            total_NOx += float(row[1]) * float(row[2]) * 3600
    for row in particle_array[1:]:
        if row[3] == "炼钢厂":
            total_particle += float(row[0]) * float(row[1]) * 3600
    if flag == 1:
        return "炼钢厂二氧化硫排放量：" + str('{:2f}'.format(total_SO2 / 1000000000)) + "t，氮氧化物排放量：" + str(
            '{:2f}'.format(total_NOx / 1000000000)) + "t"
    elif flag == 2:
        return str('{:2f}'.format(total_SO2 / 1000000000))
    elif flag == 3:
        return str('{:2f}'.format(total_NOx / 1000000000))
    elif flag == 4:
        return str('{:2f}'.format(total_particle / 1000000000))

def TC(cems_array,flag,particle_array):
    total_SO2 = 0
    total_NOx = 0
    total_particle = 0
    for row in cems_array[1:]:
        if row[4] == "条材厂":
            total_SO2 += float(row[0]) * float(row[2]) * 3600
            total_NOx += float(row[1]) * float(row[2]) * 3600
    for row in particle_array[1:]:
        if row[3] == "条材厂":
            total_particle += float(row[0]) * float(row[1]) * 3600
    if flag == 1:
        return "条材厂二氧化硫排放量：" + str('{:2f}'.format(total_SO2 / 1000000000)) + "t，氮氧化物排放量：" + str(
            '{:2f}'.format(total_NOx / 1000000000)) + "t"
    elif flag == 2:
        return str('{:2f}'.format(total_SO2 / 1000000000))
    elif flag == 3:
        return str('{:2f}'.format(total_NOx / 1000000000))
    elif flag == 4:
        return str('{:2f}'.format(total_particle / 1000000000))

def RZ(cems_array,flag,particle_array):
    total_SO2 = 0
    total_NOx = 0
    total_particle = 0
    for row in cems_array[1:]:
        if row[4] == "热轧厂":
            total_SO2 += float(row[0]) * float(row[2]) * 3600
            total_NOx += float(row[1]) * float(row[2]) * 3600
    for row in particle_array[1:]:
        if row[3] == "热轧厂":
            total_particle += float(row[0]) * float(row[1]) * 3600
    if flag == 1:
        return "热轧厂二氧化硫排放量：" + str('{:2f}'.format(total_SO2 / 1000000000)) + "t，氮氧化物排放量：" + str(
            '{:2f}'.format(total_NOx / 1000000000)) + "t"
    elif flag == 2:
        return str('{:2f}'.format(total_SO2 / 1000000000))
    elif flag == 3:
        return str('{:2f}'.format(total_NOx / 1000000000))
    elif flag == 4:
        return str('{:2f}'.format(total_particle / 1000000000))

def LZ(cems_array,flag,particle_array):
    total_SO2 = 0
    total_NOx = 0
    total_particle = 0
    for row in cems_array[1:]:
        if row[4] == "冷轧厂":
            total_SO2 += float(row[0]) * float(row[2]) * 3600
            total_NOx += float(row[1]) * float(row[2]) * 3600
    for row in particle_array[1:]:
        if row[3] == "冷轧厂" and row[2] != "DA204" and row[2] != "DA820":
            total_particle += float(row[0]) * float(row[1]) * 3600
    if flag == 1:
        return "冷轧厂二氧化硫排放量：" + str('{:2f}'.format(total_SO2 / 1000000000)) + "t，氮氧化物排放量：" + str(
            '{:2f}'.format(total_NOx / 1000000000)) + "t"
    elif flag == 2:
        return str('{:2f}'.format(total_SO2 / 1000000000))
    elif flag == 3:
        return str('{:2f}'.format(total_NOx / 1000000000))
    elif flag == 4:
        return str('{:2f}'.format(total_particle / 1000000000))

def NH(cems_array,flag,particle_array):
    total_SO2 = 0
    total_NOx = 0
    total_particle = 0
    for row in cems_array[1:]:
        if row[4] == "能环部":
            total_SO2 += float(row[0]) * float(row[2]) * 3600
            total_NOx += float(row[1]) * float(row[2]) * 3600
    for row in particle_array[1:]:
        if row[3] == "能环部":
            total_particle += float(row[0]) * float(row[1]) * 3600
    if flag == 1:
        return "能环部二氧化硫排放量：" + str('{:2f}'.format(total_SO2 / 1000000000)) + "t，氮氧化物排放量：" + str(
            '{:2f}'.format(total_NOx / 1000000000)) + "t"
    elif flag == 2:
        return str('{:2f}'.format(total_SO2 / 1000000000))
    elif flag == 3:
        return str('{:2f}'.format(total_NOx / 1000000000))
    elif flag == 4:
        return str('{:2f}'.format(total_particle / 1000000000))

if __name__ == '__main__':
    Total()