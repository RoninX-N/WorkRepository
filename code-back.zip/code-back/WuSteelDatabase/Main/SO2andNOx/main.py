import tkinter as tk
from tkinter import messagebox
import totalofso2andnox
import pandas as pd
import numpy as np
from openpyxl import load_workbook
from datetime import datetime
from openpyxl.styles import PatternFill

CEMSDATAFILEPATH = "D:\\CEMS设施监测历史数据.xlsx"
RESULTINPUTFILEPATH = "D:\\各工序日排放量.xlsx"
RESULTINPUTFILEPATHDETAILVERSION = "D:\\各工序日排放量 ------ 详细版.xlsx"
RESULTOUTPUTFILEPATH = "D:\\各工序日排放量（结果）.xlsx"
RESULTOUTPUTFILEPATHDETAILVERSION = "D:\\各工序日排放量 ------ 详细版（结果）.xlsx"

# 定义填充样式
fill_color_yellow = PatternFill(start_color='FFFF99',  # 颜色代码，RGB格式
                         end_color='FFFF99',
                         fill_type='solid')     # 填充类型

fill_color_red = PatternFill(start_color='FF6666',  # 颜色代码，RGB格式
                         end_color='FF6666',
                         fill_type='solid')     # 填充类型

def on_button_click_simple_version():
    total_cems_data_sheet = pd.read_excel(CEMSDATAFILEPATH, header=None)
    cems_array = np.array([['二氧化硫', '氮氧化物', '流量', '编号', '分厂', '时间']])
    for row in total_cems_data_sheet.iloc[2:].itertuples(index=False):
        if "GD" in row[0] or "WINS" in row[0]:
            pass
        else:
            if not str(row[8]) == 'nan':
                if str(row[11]) == 'nan':
                    newrow = [row[8], 0, row[27], row[0], row[2], row[4]]
                else:
                    newrow = [row[8], row[11], row[27], row[0], row[2], row[4]]
                cems_array = np.vstack((cems_array, newrow))
    # print(cems_array)

    # 颗粒物数据数组
    particle_array = np.array([['颗粒物','流量','编号','分厂','时间']])
    for row in total_cems_data_sheet.iloc[2:].itertuples(index=False):
        if "GD" in row[0] or "WINS" in row[0]:
            pass
        else:
            newrow = [row[5], row[27], row[0], row[2], row[4]]
            particle_array = np.vstack((particle_array, newrow))
    # print(particle_array)


    time_data = cems_array[1][5]

    # 简化版模板读入
    result_input_workbook = load_workbook(RESULTINPUTFILEPATH)
    result_input_sheet0 = result_input_workbook["二氧化硫"]
    result_input_sheet1 = result_input_workbook["氮氧化物"]
    result_input_sheet2 = result_input_workbook["颗粒物"]

    # messagebox.showinfo(title="二氧化硫与氮氧化物总排放量如下", message=totalofso2andnox.Total(cems_array,1,) + "\n" + totalofso2andnox.Wusteel(cems_array,1) + "\n" + totalofso2andnox.JH(cems_array,1) + "\n"
    #                     + totalofso2andnox.LT(cems_array,1) + "\n" + totalofso2andnox.LG(cems_array,1) + "\n" + totalofso2andnox.TC(cems_array,1) + "\n" + totalofso2andnox.RZ(cems_array,1) + "\n"
    #                     + totalofso2andnox.LZ(cems_array,1) + "\n" + totalofso2andnox.NH(cems_array,1) + "\n" + "文件输出成功！")
    messagebox.showinfo(title="",message="文件输出成功！")

    find_None = 3
    # print(result_input_sheet0.cell(row=3,column=1).value)
    while result_input_sheet0.cell(row = find_None,column = 1).value is not None:
        find_None += 1
    # if result_input_sheet0.cell(row = find_None,column = 1).value is not datetime.today().strftime("%m月%d日"):
    result_input_sheet0.cell(row = find_None,column = 1).value = datetime.strptime(str(time_data), "%Y-%m-%d %H:%M:%S").date().strftime("%m月%d日")
    result_input_sheet0.cell(row = find_None,column = 2).value = float(totalofso2andnox.LT(cems_array,2,particle_array))
    result_input_sheet0.cell(row = find_None,column = 4).value = float(totalofso2andnox.TC(cems_array,2,particle_array))
    result_input_sheet0.cell(row = find_None,column = 6).value = float(totalofso2andnox.RZ(cems_array,2,particle_array))
    result_input_sheet0.cell(row = find_None,column = 8).value = float(totalofso2andnox.LZ(cems_array,2,particle_array))
    result_input_sheet0.cell(row = find_None,column = 10).value = float(totalofso2andnox.NH(cems_array,2,particle_array))
    result_input_sheet0.cell(row = find_None,column = 12).value = float(totalofso2andnox.JH(cems_array,2,particle_array))
    result_input_sheet0.cell(row = find_None,column = 14).value = float(totalofso2andnox.Total(cems_array,2,particle_array))

    # if result_input_sheet1.cell(row=find_None, column=1).value is not datetime.today().strftime("%m月%d日"):
    result_input_sheet1.cell(row=find_None, column=1).value = datetime.strptime(str(time_data), "%Y-%m-%d %H:%M:%S").date().strftime("%m月%d日")
    result_input_sheet1.cell(row=find_None, column=2).value = float(totalofso2andnox.LT(cems_array, 3,particle_array))
    result_input_sheet1.cell(row=find_None, column=4).value = float(totalofso2andnox.TC(cems_array, 3,particle_array))
    result_input_sheet1.cell(row=find_None, column=6).value = float(totalofso2andnox.RZ(cems_array, 3,particle_array))
    result_input_sheet1.cell(row=find_None, column=8).value = float(totalofso2andnox.LZ(cems_array, 3,particle_array))
    result_input_sheet1.cell(row=find_None, column=10).value = float(totalofso2andnox.NH(cems_array, 3,particle_array))
    result_input_sheet1.cell(row=find_None, column=12).value = float(totalofso2andnox.JH(cems_array, 3,particle_array))
    result_input_sheet1.cell(row=find_None, column=14).value = float(totalofso2andnox.Total(cems_array, 3,particle_array))

    # print(particle_array)
    result_input_sheet2.cell(row=find_None, column=1).value = datetime.strptime(str(time_data),"%Y-%m-%d %H:%M:%S").date().strftime("%m月%d日")
    result_input_sheet2.cell(row=find_None, column=2).value = float(totalofso2andnox.LT(cems_array, 4, particle_array))
    result_input_sheet2.cell(row=find_None, column=4).value = float(totalofso2andnox.TC(cems_array, 4, particle_array))
    result_input_sheet2.cell(row=find_None, column=6).value = float(totalofso2andnox.RZ(cems_array, 4, particle_array))
    result_input_sheet2.cell(row=find_None, column=8).value = float(totalofso2andnox.LZ(cems_array, 4, particle_array))
    result_input_sheet2.cell(row=find_None, column=10).value = float(totalofso2andnox.NH(cems_array, 4, particle_array))
    result_input_sheet2.cell(row=find_None, column=12).value = float(totalofso2andnox.JH(cems_array, 4, particle_array))
    result_input_sheet2.cell(row=find_None, column=14).value = float(totalofso2andnox.Total(cems_array, 4, particle_array))


    result_input_workbook.save(RESULTOUTPUTFILEPATH)


def on_button_click_detail_version():
    total_cems_data_sheet = pd.read_excel(CEMSDATAFILEPATH, header=None)
    cems_array = np.array([['二氧化硫', '氮氧化物', '流量', '编号', '分厂', '时间']])
    for row in total_cems_data_sheet.iloc[2:].itertuples(index=False):
        if "GD" in row[0] or "WINS" in row[0]:
            pass
        else:
            if not str(row[8]) == 'nan':
                if str(row[11]) == 'nan':
                    newrow = [row[8], 0, row[27], row[0], row[2], row[4]]
                else:
                    newrow = [row[8], row[11], row[27], row[0], row[2], row[4]]
                cems_array = np.vstack((cems_array, newrow))

    # 颗粒物数据数组
    particle_array = np.array([['颗粒物', '流量', '编号', '分厂', '时间']])
    for row in total_cems_data_sheet.iloc[2:].itertuples(index=False):
        if "GD" in row[0] or "WINS" in row[0]:
            pass
        else:
            newrow = [row[5], row[27], row[0], row[2], row[4]]
            particle_array = np.vstack((particle_array, newrow))

    # 详细版模板读入
    detail_result_input_workbook = load_workbook(RESULTINPUTFILEPATHDETAILVERSION)
    detail_result_input_sheet0 = detail_result_input_workbook["二氧化硫"]
    detail_result_input_sheet1 = detail_result_input_workbook["氮氧化物"]
    detail_result_input_sheet2 = detail_result_input_workbook["颗粒物"]

    # 遍历第一列（A列），获取点位到point_list中
    point_list = []
    for row in range(4, detail_result_input_sheet0.max_row + 1):
        cell_value = detail_result_input_sheet0.cell(row=row, column=2).value  # 第一列的值
        point_list.append(cell_value)
    # 搞一个list存放各点位编号、二氧化硫计算值、氮氧化物计算值，搞一个时间变量用于判断应该放第几列
    time_data = cems_array[1][5]
    detail_data_list = np.array([['点位编号', '二氧化硫', '氮氧化物','颗粒物']])
    for point in point_list:
        total_SO2 = 0
        total_NOx = 0
        total_particle = 0
        for row in cems_array[1:]:
            if row[3] == point:
                total_SO2 += float(row[0]) * float(row[2]) * 3600/1000000000
                total_NOx += float(row[1]) * float(row[2]) * 3600/1000000000
        for row in particle_array[1:]:
            if row[2] == point:
                total_particle += float(row[0]) * float(row[1]) * 3600/1000000000
        newrow = [point,total_SO2,total_NOx,total_particle]
        detail_data_list = np.vstack((detail_data_list,newrow))
    # print(detail_data_list)
    i = 4
    for col in range(4, detail_result_input_sheet0.max_column + 1):
        cell_value = detail_result_input_sheet0.cell(row=2, column=col).value  # 访问每个单元格值
        if cell_value.date() == datetime.strptime(str(time_data), "%Y-%m-%d %H:%M:%S").date():
            break
        else:
            i += 1
    count = 1
    for row in detail_data_list[1:]:
        detail_result_input_sheet0.cell(row = count + 3, column = i).value = float(row[1])
        detail_result_input_sheet1.cell(row = count + 3, column = i).value = float(row[2])
        detail_result_input_sheet2.cell(row = count + 3, column = i).value = float(row[3])
        if i > 4:
            cell_value = float(detail_result_input_sheet0.cell(row = count+3,column = i-1).value) if detail_result_input_sheet0.cell(row = count+3,column = i-1).value is not None else 0.0  # 处理 None 值
            if cell_value < float(row[1]):
                detail_result_input_sheet0.cell(row=count+3, column=i).fill = fill_color_red
            cell_value = float(detail_result_input_sheet1.cell(row = count+3,column = i-1).value) if detail_result_input_sheet1.cell(row = count+3,column = i-1).value is not None else 0.0
            if cell_value < float(row[2]):
                detail_result_input_sheet1.cell(row=count+3, column=i).fill = fill_color_red
            cell_value = float(detail_result_input_sheet2.cell(row=count + 3,column = i-1).value) if detail_result_input_sheet2.cell(row = count+3,column = i-1).value is not None else 0.0
            if cell_value < float(row[3]):
                detail_result_input_sheet2.cell(row=count+3, column=i).fill = fill_color_red
        count += 1

    detail_result_input_workbook.save(RESULTOUTPUTFILEPATHDETAILVERSION)
    messagebox.showinfo(title="", message="文件输出成功！")

if __name__ == '__main__':
    app = tk.Tk()
    app.title("计算二氧化硫与氮氧化物日排放量")
    app.geometry("350x150")
    app.configure(bg='lightblue')

    label = tk.Label(app, text="将数据文件放D盘根目录后点击一键输出")
    label.pack(pady=10)

    button = tk.Button(app, text="一键输出简单版", command=on_button_click_simple_version)
    button.pack(pady=5)

    button = tk.Button(app, text="一键输出详细版", command=on_button_click_detail_version)
    button.pack(pady=5)

    app.mainloop()

