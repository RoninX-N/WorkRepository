# <editor-fold desc = '填写执行年报手工有组织数据'>
import pandas as pd
import numpy as np
from openpyxl import load_workbook

TEMPFILEPATH = "D:\\elseFile\\work\\Codeworkbench\\年度执行报告\\年度执行报告手工填写模板.xlsx"
DATAFILEPATH = "D:\\elseFile\\work\\Codeworkbench\\年度执行报告\\DATA.xlsx"
OUTPUTFILEPATH = "D:\\elseFile\\work\\Codeworkbench\\年度执行报告\\年度执行报告手工填写模板（完成）.xlsx"

if __name__ == '__main__':
    data_sheet = pd.read_excel(DATAFILEPATH,header=None)
    data_array = [['DA号','监测因子','日期','实测浓度']]
    for row in data_sheet.iloc[1:].itertuples(index=False):
        newrow = [row[1],row[4],row[9],row[11]]
        data_array = np.vstack((data_array,newrow))
    temp_workbook = load_workbook(TEMPFILEPATH)
    temp_sheet = temp_workbook['4-1 有组织废气污染物排放浓度监测数据统计表']
    i = 6
    while i <= 609:
        temp = []
        for row in data_array[1:]:
            if row[0] == temp_sheet.cell(row = i,column = 1).value and row[1] == temp_sheet.cell(row = i,column = 2).value:
                temp.append(row[3])
        print(temp)
        count = 0
        MIN = 999999.0
        MAX = 0.0
        averge = 0
        for D in temp:
            flag = ''
            print(D)
            if D != "" and D != "/":
                count = count + 1
                if D == "ND":
                    flag = 'ND'
                if flag == 'ND':
                    MIN = 'ND'
                else:
                    if MIN != 'ND': # 这里这样写是因为数据里面只有“ND”，“/”，“数字字符”三种类型数据或者单元格为空
                        if float(D) < MIN:
                            MIN = float(D)
                if D != 'ND':
                    if float(D) > MAX:
                        MAX = float(D)
                if D != "ND": # 这里同上MIN原因
                    averge = averge + float(D)
        if MAX == 0.0 and flag == 'ND':
            MAX = 'ND'
        try:
            averge = averge/count
        except:
            MIN = '无'
            MAX = '无'
            averge = '无'
        temp_sheet.cell(row = i,column = 5).value = count
        temp_sheet.cell(row = i,column = 6).value = MIN
        temp_sheet.cell(row = i,column = 7).value = MAX
        temp_sheet.cell(row = i,column = 8).value = averge
        i = i + 1
    temp_workbook.save(OUTPUTFILEPATH)
# </editor-fold>

# <editor-fold desc = '填写执行年报手工废水数据'>
import pandas as pd
import numpy as np
from openpyxl import load_workbook


TEMPFILEPATH = "D:\\elseFile\\work\\Codeworkbench\\年度执行报告\\年度执行报告手工填写模板_水.xlsx"
DATAFILEPATH = "D:\\elseFile\\work\\Codeworkbench\\年度执行报告\\DATA_water.xlsx"
OUTPUTFILEPATH = "D:\\elseFile\\work\\Codeworkbench\\年度执行报告\\年度执行报告手工填写模板_水（完成）.xlsx"

if __name__ == '__main__':
    data_sheet = pd.read_excel(DATAFILEPATH, header=None)
    data_array = [['DW号', '监测因子', '日期', '实测浓度']]
    for row in data_sheet.iloc[1:].itertuples(index=False):
        newrow = [row[1],row[4],row[10],row[12]]
        data_array = np.vstack((data_array,newrow))
    temp_workbook = load_workbook(TEMPFILEPATH)
    temp_sheet = temp_workbook['4-4 废水污染物排放浓度监测数据统计表']
    i = 4
    while i <= 140:
        temp = []
        for row in data_array[1:]:
            if row[0] == temp_sheet.cell(row = i,column = 1).value and row[1] == temp_sheet.cell(row = i,column = 2).value:
                temp.append(row[3])
        # print(temp)
        count = 0
        MIN = 999999.0
        MAX = 0.0
        averge = 0
        for D in temp:
            flag = ''
            print(D)
            if D != "" and D != "/":
                count = count + 1
                if D == "ND":
                    flag = 'ND'
                if flag == 'ND':
                    MIN = 'ND'
                else:
                    if MIN != 'ND': # 这里这样写是因为数据里面只有“ND”，“/”，“数字字符”三种类型数据或者单元格为空
                        if float(D) < MIN:
                            MIN = float(D)
                if D != 'ND':
                    if float(D) > MAX:
                        MAX = float(D)
                if D != "ND": # 这里同上MIN原因
                    averge = averge + float(D)
        if MAX == 0.0 and flag == 'ND':
            MAX = 'ND'
        try:
            averge = averge/count
        except:
            MIN = '无'
            MAX = '无'
            averge = '无'
        temp_sheet.cell(row=i, column=5).value = count
        temp_sheet.cell(row=i, column=6).value = MIN
        temp_sheet.cell(row=i, column=7).value = MAX
        temp_sheet.cell(row=i, column=8).value = averge
        i = i + 1
        temp_workbook.save(OUTPUTFILEPATH)

# </editor-fold>
