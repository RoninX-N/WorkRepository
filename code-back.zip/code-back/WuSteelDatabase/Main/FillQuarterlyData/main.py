import pandas as pd
from openpyxl import load_workbook
import os

template_path_water = 'D:\\elseFile\\work\\临时工作\\4-6月日均值-2024.7.2\\填写表\\季报工业企业废水常规污染物自动监测数据.xls'
template_path_gas = 'D:\\elseFile\\work\\临时工作\\4-6月日均值-2024.7.2\\填写表\\季报工业企业废气自动监测数据.xls'
input_folder_water = 'D:\\elseFile\\work\\临时工作\\4-6月日均值-2024.7.2\\数据表\\水'
input_folder_gas = 'D:\\elseFile\\work\\临时工作\\4-6月日均值-2024.7.2\\数据表\\气'
output_folder = 'D:\\elseFile\\work\\临时工作\\4-6月日均值-2024.7.2\\输出文件'

def write_in_read_out(template_path_water,template_path_gas,input_folder_water,input_folder_gas,output_folder):
    files_water = [f for f in os.listdir(input_folder_water) if f.endswith('.xlsx')]


if __name__ == '__main__':
    pass