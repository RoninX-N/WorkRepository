# -*- coding: utf-8 -*- 
# @Time : 2024/1/16 15:35 
# @Author : RoninX

def main():

    print()

if __name__ == "__main__":
    main()
