# -*- coding: utf-8 -*- 
# @Time : 2024/1/17 9:10 
# @Author : RoninX

import openpyxl
import pymysql

# <editor-fold desc='各种常量定义'>
PLANNEDMISSIONTABLE = "plannedmissions2024"
PLANNEDDATATABLE = "planneddatacollection2024"
# </editor-fold>

# <editor-fold desc='对数据库进行连接等基本操作的函数'>
def get_conn():
    return pymysql.connect(
        host='127.0.0.1',
        user='root',
        password='root',
        database='wusteeldatabase',
        charset='utf8'
    )
# </editor-fold>

# 添加新的数据到plannedmissions2024数据库里（添加监测计划）
def addtomission(sheet):# 传入整个任务数组将其插入
    conn = get_conn()
    cursor = conn.cursor()

    # <editor-fold desc='读入表对应列'>
    completeunitcolumn = -1
    plantypecolumn = -1
    monitoringtypecolumn = -1
    contaminationtypecolumn = -1
    factorynamecolumn = -1
    monitoringpointcolumn = -1
    monitoringfactorcolumn = -1
    frequencycolumn = -1
    missionsheetcount = 0
    firstrow = sheet[1]
    for x in firstrow:
        missionsheetcount += 1
        if x.value == "完成单位":
            completeunitcolumn = missionsheetcount-1
        if x.value == "计划类别":
            plantypecolumn = missionsheetcount-1
        if x.value == "监测方式":
            monitoringtypecolumn = missionsheetcount-1
        if x.value == "污染类别":
            contaminationtypecolumn = missionsheetcount-1
        if x.value == "厂名":
            factorynamecolumn = missionsheetcount-1
        if x.value == "监测点位":
            monitoringpointcolumn = missionsheetcount-1
        if x.value == "监测因子":
            monitoringfactorcolumn = missionsheetcount-1
        if x.value == "监测频次":
            frequencycolumn = missionsheetcount-1
    # </editor-fold>

    for row in sheet.iter_rows(min_row=2, values_only=True):
        if len(row[monitoringfactorcolumn]) < 255:
            insertrow = [row[completeunitcolumn],row[plantypecolumn],row[monitoringtypecolumn],row[contaminationtypecolumn],row[factorynamecolumn],row[monitoringpointcolumn],row[monitoringfactorcolumn],row[frequencycolumn],"暂无"]
        else:# 还没具体分项时写的，是冗余的
            insertrow = [row[completeunitcolumn], row[plantypecolumn], row[monitoringtypecolumn], row[contaminationtypecolumn],
                         row[factorynamecolumn], row[monitoringpointcolumn], row[monitoringfactorcolumn][:255], row[frequencycolumn],
                         "暂无"]
        sql = f"INSERT INTO {PLANNEDMISSIONTABLE} (`completeunit`,`plantype`,`monitoringtype`,`contaminationtype`,`factoryname`,`monitoringpoint`,`monitoringfactor`,`frequency`,`else`) VALUES ( %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        cursor.execute(sql, insertrow)
    conn.commit()
    cursor.close()
    conn.close()

# 添加新的数据到planneddatacollection2024数据库里（添加监测数据）
def addtodata(sheet):# 传入整个数据数组将其插入
    conn = get_conn()
    cursor = conn.cursor()

    # <editor-fold desc='读入表对应列'>
    completeunitcolumn = -1
    plantypecolumn = -1
    monitoringtypecolumn = -1
    contaminationtypecolumn = -1
    factorynamecolumn = -1
    monitoringpointcolumn = -1
    monitoringfactorcolumn = -1
    frequencycolumn = -1
    standardcolumn = -1
    limitscolumn = -1
    monitordatecolumn = -1
    reportnumbercolumn = -1
    measuredconcentrationcolumn = -1
    convertedconcentrationcolumn = -1
    windflowcolumn = -1
    anomalycolumn = -1
    datasheetcount = -1
    firstrow = sheet[1]
    for x in firstrow:
        datasheetcount += 1
        if x.value == "实施单位":
            completeunitcolumn = datasheetcount
        if x.value == "优先级":
            plantypecolumn = datasheetcount
        if x.value == "监测方式":
            monitoringtypecolumn = datasheetcount
        if x.value == "类别3":
            contaminationtypecolumn = datasheetcount


    # </editor-fold>

    # <editor-fold desc='这里写一个将数据库里所有colunm相同的重复项去掉的步骤'>

    # </editor-fold>
    print()

# 筛选相同点位相同因子相同时间监测的重复记录用print()输出出来看看是否应该删除
def checkduplicate():

    print()

# 删除数据表中重复的记录
def deleteduplicate():

    print()

# 修改mission中的记录
def modifymission():

    print()

# 后面写查询数据的方法




# 调试：
def main():
    # <editor-fold desc='将年度任务读入数据库任务table'>
    missionfilepath = "D:\\elseFile\\work\\Codeworkbench\\ChartTemplate\\2024总任务表.xlsx"
    missionworkbook = openpyxl.load_workbook(missionfilepath)
    missionsheet = missionworkbook["计划内"]
    addtomission(missionsheet)
    # </editor-fold>

    # <editor-fold desc='将新的数据读入数据table并输出重复项查看'>
    # datafilepath = "D:\\elseFile\\work\\Codeworkbench\\ChartTemplate\\2024总任务表.xlsx"
    # dataworkbook = openpyxl.load_workbook(datafilepath)
    # datasheet = dataworkbook["计划内"]
    # addtodata(datasheet)
    # print()
    # </editor-fold>

if __name__ == "__main__":
    main()