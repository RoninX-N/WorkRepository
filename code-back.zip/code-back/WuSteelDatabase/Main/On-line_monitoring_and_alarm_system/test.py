import pprint

import requests
import ddddocr
from PIL import Image
from selenium import webdriver

headers = {
    "Accept": "application/json, text/plain, */*",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NDE1ODg0NjgsIm5iZiI6MTc0MDk4MzY2OCwidWluIjo0OTcsIndvciI6ZmFsc2UsIndvZSI6dHJ1ZSwiY2EiOmZhbHNlLCJjZSI6ZmFsc2UsImNkIjpmYWxzZSwiY20iOmZhbHNlLCJycCI6ZmFsc2UsInJvbGVzIjpbM119.Hy9A70_mYuRgKiqdZEC4tMJYFL7LdQ2pvAWEOtZM0yI",
    "Connection": "keep-alive",
    "Cookie": "User-Set-Pwd=false; WorkOrderEdit=1; User-Token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3NDA3MjU5OTMsIm5iZiI6MTc0MDEyMTE5MywidWluIjo0OTcsIndvciI6ZmFsc2UsIndvZSI6dHJ1ZSwiY2EiOmZhbHNlLCJjZSI6ZmFsc2UsImNkIjpmYWxzZSwiY20iOmZhbHNlLCJycCI6ZmFsc2UsInJvbGVzIjpbM119.Hy9A70_mYuRgKiqdZEC4tMJYFL7LdQ2pvAWEOtZM0yI",
    "Host": "59.173.11.86:8000",
    "Referer": "https://59.173.11.86:8000/",
    "Sec-CH-UA": '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
    "Sec-CH-UA-Mobile": "?0",
    "Sec-CH-UA-Platform": '"Windows"',
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-origin",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
}

captcha_url = "https://59.173.11.86:8000/apis/captcha"

if __name__ == '__main__':
    data = {
        'captcha_id': 'KtuJQm69QV9BBboNQZOK',  # 不是固定
        'captcha_value': '3mqw',  # 不是固定
        'name': '武汉钢铁',
        'password': '4d863b33ffd65e8c80ee0d337c823f7d604880f2'
    }
    url = "https://59.173.11.86:8000/#/login"

    session = requests.Session()

    driver = webdriver.Chrome(executable_path='D:\CODEproject\chromedriver-win64\chromedriver.exe')
    driver.maximize_window()  # 将浏览器最大化
    driver.get(url)
    # 截取当前网页并放到D盘下命名为printscreen，该网页有验证码
    driver.save_screenshot('D:\\CODEproject\\python\\WuSteelDatabase\\Main\\On-line_monitoring_and_alarm_system\\picture\\printscreen.png')
    imgelement = driver.find_element_by_class_name('captcha-image')  # 定位验证码
    location = imgelement.location  # 获取验证码x,y轴坐标
    size = imgelement.size  # 获取验证码的长宽
    rangle = (int(location['x'] + 197), int(location['y'] + 80), int(location['x'] + size['width'] + 225),
              int(location['y'] + size['height'] + 92))  # 写成我们需要截取的位置坐标
    i = Image.open("D:\\CODEproject\\python\\WuSteelDatabase\\Main\\On-line_monitoring_and_alarm_system\\picture\\printscreen.png")  # 打开截图
    frame4 = i.crop(rangle)  # 使用Image的crop函数，从截图中再次截取我们需要的区域
    frame4 = frame4.convert('RGB')
    frame4.save('D:\\CODEproject\\python\\WuSteelDatabase\\Main\\On-line_monitoring_and_alarm_system\\picture\\save.jpg')  # 保存我们接下来的验证码图片 进行打码

    ocr = ddddocr.DdddOcr(show_ad=False)
    with open("D:\\CODEproject\\python\\WuSteelDatabase\\Main\\On-line_monitoring_and_alarm_system\\picture\\save.jpg","rb") as f:
        image = f.read()
    print(ocr.classification(image))

    data['captcha_value'] = ocr.classification(image)

    response = requests.get(captcha_url, verify=False)  # verify=False 用于忽略 SSL 验证
    # 检查响应状态
    if response.status_code == 200:
        # 获取返回的 JSON 数据
        data_captcha = response.json()
        # 提取 captcha_id
        captcha_id = data_captcha.get('data', {}).get('captcha_id')
        if captcha_id:
            print(f"Captcha ID: {captcha_id}")
        else:
            print("Captcha ID not found.")
    else:
        print(f"Request failed with status code: {response.status_code}")
    # print(captcha_id)
    data['captcha_id'] = captcha_id
    print(data)

    # 发送POST请求进行登录
    response = session.get(url, headers=headers, data=data, verify=False)
    # 检查是否登录成功
    if response.status_code == 200:
        print("登录成功！")

        # 获取登录后页面的内容
        page_url = "https://59.173.11.86:8000/apis/datas/history?device_id=61510002003745&data_type=hour&start_time=1741928400&end_time=1742274000"  # 登录后的页面URL
        page_response = session.get(page_url, headers=headers, verify=False)

        if page_response.status_code == 200:
            print("获取页面成功")
            # 打印页面内容
            pprint.pprint(page_response.text)  # 或者 page_response.content，如果需要二进制内容的话
            token = response.json().get("token")
            print("Token:", token)
        else:
            print(f"获取页面失败，状态码：{page_response.status_code}")
    else:
        print(f"登录失败，状态码：{response.status_code}")




