import pandas as pd
from openpyxl import load_workbook
import numpy as np
import datetime

# <editor-fold desc='文件路径定义'>
DATA_FILE_PATH = "D:\\OperationForProcess\\2025年总任务表.xlsx"
OUTPUT_FILE_FATH = "D:\\OperationForProcess\\2025年总任务表（结果）.xlsx"
# </editor-fold>

if __name__ == '__main__':
    data_form = load_workbook(DATA_FILE_PATH)
    print(data_form.sheetnames)
    data_sheet = data_form["监测任务基础数据表"]
    print(data_sheet)


