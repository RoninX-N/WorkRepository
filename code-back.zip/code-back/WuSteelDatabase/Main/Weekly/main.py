import pandas as pd
from openpyxl import load_workbook
from datetime import datetime,timedelta

# <editor-fold scr='定义各种常量'>
ALLALARMSTABLEPATH = "D:\\elseFile\\work\\Codeworkbench\\ChartTemplate\\2024年年度超标统计.xlsx"
INPUTFILEPATH = "D:\\elseFile\\work\\Codeworkbench\\ChartTemplate\\PPT周报数据表模板.xlsx"
OUTPUTFILEPATH = "D:\\elseFile\\work\\Codeworkbench\\ChartOutPut\\PPT周报数据表模板.xlsx"
CEMS = 'CEMS'
TSP = 'TSP'
GOVERN = '环保设备'

IRONMAKE = "炼铁厂"
STEELMAKE = "炼钢厂"
STRIPS = "条材厂"
HOTROLL = "热轧厂"
COLDROLL = "冷轧厂"
SILICONSTEEL = "硅钢部"
STEELELECTRICITY = "钢电公司"
TRANSPORT = "运输部"
EAEP = "能环部"

CALIBRATION = "检校"
STOPPAGE = "启停"
OPERATECONDITION = "工况"
PROCESSED = "已处理"
NOTPROCESSED = "未处理"
APPROVED = "审核通过"
GOVERNANCEFACILITIES = "治理设施"
TVOC = "TVOC监测仪"
UNLINKAGE = "未联动开启"
DIFFERENTIALPRESSUREOVERRUN = "除尘器连续超出额定压差范围"
FANSCURRENTOVERRUN = "风机电流连续超过额定电流"
# </editor-fold>

def main():
    template_workbook = load_workbook(INPUTFILEPATH)
    template_sheet = template_workbook['main']
    # <editor-fold scr='统计CEMS数据并填入template表中'>
    CEMS_sheet = pd.read_excel(ALLALARMSTABLEPATH,sheet_name='CEMS')

    current_datetime = datetime.now()
    # current_datetime = datetime(2024,1,19,14,38)
    # <editor-fold src='将上周到这周的数据统计填入表中'>
    # <editor-fold src='找上周时间节点的两端'>
    if current_datetime.weekday()==0:
        last_thursday = current_datetime - timedelta(days=3)
    elif current_datetime.weekday()==1:
        last_thursday = current_datetime - timedelta(days=4)
    elif current_datetime.weekday()==2:
        last_thursday = current_datetime - timedelta(days=5)
    elif current_datetime.weekday()==3:
        last_thursday = current_datetime - timedelta(days=6)
    elif current_datetime.weekday()==4:
        last_thursday = current_datetime - timedelta(days=7)
    elif current_datetime.weekday()==5:
        last_thursday = current_datetime - timedelta(days=8)
    elif current_datetime.weekday()==6:
        last_thursday = current_datetime - timedelta(days=9)
    # 这里临时改一下时间段
    last_friday_start = datetime(last_thursday.year, last_thursday.month, last_thursday.day, 16, 0) - timedelta(days=1)
    print("last_friday_start:" + str(last_friday_start))
    # last_friday_start = datetime(2024,2,18,0,0)
    if current_datetime.weekday() == 0:
        this_thursday = current_datetime + timedelta(days=3)
    elif current_datetime.weekday() == 1:
        this_thursday = current_datetime + timedelta(days=2)
    elif current_datetime.weekday() == 2:
        this_thursday = current_datetime + timedelta(days=1)
    elif current_datetime.weekday() == 3:
        this_thursday = current_datetime
    elif current_datetime.weekday() == 4:
        this_thursday = current_datetime - timedelta(days=1)
    elif current_datetime.weekday() == 5:
        this_thursday = current_datetime - timedelta(days=2)
    elif current_datetime.weekday() == 6:
        this_thursday = current_datetime - timedelta(days=3)
    # 这里临时改一下时间
    this_thursday_end = datetime(this_thursday.year, this_thursday.month, this_thursday.day, 15, 0)
    print("this_thursday_end" + str(this_thursday_end))
    # this_thursday_end = datetime(2024,2,22,16,0)
    # </editor-fold>
    # <editor-fold scr='定义cems计数变量'>
    # 检校各厂部
    caironmake = 0
    casteelmake = 0
    castrips = 0
    cahotroll = 0
    cacoldroll = 0
    casiliconsteel = 0
    casteelelectricity = 0
    catransport = 0
    caeaep = 0
    # 启停炉各厂部
    stironmake = 0
    ststeelmake = 0
    ststrips = 0
    sthotroll = 0
    stcoldroll = 0
    stsiliconsteel = 0
    ststeelelectricity = 0
    sttransport = 0
    steaep = 0
    # 工况各厂部
    opironmake = 0
    opsteelmake = 0
    opstrips = 0
    ophotroll = 0
    opcoldroll = 0
    opsiliconsteel = 0
    opsteelelectricity = 0
    optransport = 0
    opeaep = 0
    # 故障各厂部
    erironmake = 0
    ersteelmake = 0
    erstrips = 0
    erhotroll = 0
    ercoldroll = 0
    ersiliconsteel = 0
    ersteelelectricity = 0
    ertransport = 0
    ereaep = 0
    # </editor-fold>
    for row in CEMS_sheet.iloc[1:].itertuples(index=False):
        if last_friday_start <= datetime.strptime(row[11],"%Y-%m-%d %H:%M") <= this_thursday_end:
            # print(row[11])
            if row[0] == 'CEMS故障':
                if row[3] == IRONMAKE:
                    erironmake += 1
                if row[3] == STEELMAKE:
                    ersteelmake += 1
                if row[3] == STRIPS:
                    erstrips += 1
                if row[3] == HOTROLL:
                    erhotroll += 1
                if row[3] == COLDROLL:
                    ercoldroll += 1
                if row[3] == SILICONSTEEL:
                    ersiliconsteel += 1
                if row[3] == STEELELECTRICITY:
                    ersteelelectricity += 1
                if row[3] == TRANSPORT:
                    ertransport += 1
                if row[3] == EAEP:
                    ereaep += 1
            elif row[0] == CALIBRATION:
                if row[3] == IRONMAKE:
                    caironmake += 1
                if row[3] == STEELMAKE:
                    casteelmake += 1
                if row[3] == STRIPS:
                    castrips += 1
                if row[3] == HOTROLL:
                    cahotroll += 1
                if row[3] == COLDROLL:
                    cacoldroll += 1
                if row[3] == SILICONSTEEL:
                    casiliconsteel += 1
                if row[3] == STEELELECTRICITY:
                    casteelelectricity += 1
                if row[3] == TRANSPORT:
                    catransport += 1
                if row[3] == EAEP:
                    caeaep += 1
            elif row[0] == STOPPAGE:
                if row[3] == IRONMAKE:
                    stironmake += 1
                if row[3] == STEELMAKE:
                    ststeelmake += 1
                if row[3] == STRIPS:
                    ststrips += 1
                if row[3] == HOTROLL:
                    sthotroll += 1
                if row[3] == COLDROLL:
                    stcoldroll += 1
                if row[3] == SILICONSTEEL:
                    stsiliconsteel += 1
                if row[3] == STEELELECTRICITY:
                    ststeelelectricity += 1
                if row[3] == TRANSPORT:
                    sttransport += 1
                if row[3] == EAEP:
                    steaep += 1
            elif row[0] == OPERATECONDITION:
                if row[3] == IRONMAKE:
                    opironmake += 1
                if row[3] == STEELMAKE:
                    opsteelmake += 1
                if row[3] == STRIPS:
                    opstrips += 1
                if row[3] == HOTROLL:
                    ophotroll += 1
                if row[3] == COLDROLL:
                    opcoldroll += 1
                if row[3] == SILICONSTEEL:
                    opsiliconsteel += 1
                if row[3] == STEELELECTRICITY:
                    opsteelelectricity += 1
                if row[3] == TRANSPORT:
                    optransport += 1
                if row[3] == EAEP:
                    opeaep += 1
    # <editor-fold scr='将统计好的数值填入对应位置（上周到这一周）'>
    template_sheet['C4'] = caironmake
    template_sheet['C5'] = casteelmake
    template_sheet['C6'] = castrips
    template_sheet['C7'] = cahotroll
    template_sheet['C8'] = cacoldroll
    template_sheet['C9'] = casiliconsteel
    template_sheet['C10'] = casteelelectricity
    template_sheet['C11'] = catransport
    template_sheet['C12'] = caeaep
    template_sheet['E4'] = stironmake
    template_sheet['E5'] = ststeelmake
    template_sheet['E6'] = ststrips
    template_sheet['E7'] = sthotroll
    template_sheet['E8'] = stcoldroll
    template_sheet['E9'] = stsiliconsteel
    template_sheet['E10'] = ststeelelectricity
    template_sheet['E11'] = sttransport
    template_sheet['E12'] = steaep
    template_sheet['G4'] = opironmake
    template_sheet['G5'] = opsteelmake
    template_sheet['G6'] = opstrips
    template_sheet['G7'] = ophotroll
    template_sheet['G8'] = opcoldroll
    template_sheet['G9'] = opsiliconsteel
    template_sheet['G10'] = opsteelelectricity
    template_sheet['G11'] = optransport
    template_sheet['G12'] = opeaep
    template_sheet['I4'] = erironmake
    template_sheet['I5'] = ersteelmake
    template_sheet['I6'] = erstrips
    template_sheet['I7'] = erhotroll
    template_sheet['I8'] = ercoldroll
    template_sheet['I9'] = ersiliconsteel
    template_sheet['I10'] = ersteelelectricity
    template_sheet['I11'] = ertransport
    template_sheet['I12'] = ereaep

    # </editor-fold>
    # </editor-fold>

    # <editor-fold desc='将上上周到上周的数据统计填入表中'>
    # <editor-fold desc='找上上周时间节点的两端'>
    if current_datetime.weekday() == 0:
        last_thursday = current_datetime - timedelta(days=10)
    elif current_datetime.weekday() == 1:
        last_thursday = current_datetime - timedelta(days=11)
    elif current_datetime.weekday() == 2:
        last_thursday = current_datetime - timedelta(days=12)
    elif current_datetime.weekday() == 3:
        last_thursday = current_datetime - timedelta(days=13)
    elif current_datetime.weekday() == 4:
        last_thursday = current_datetime - timedelta(days=14)
    elif current_datetime.weekday() == 5:
        last_thursday = current_datetime - timedelta(days=15)
    elif current_datetime.weekday() == 6:
        last_thursday = current_datetime - timedelta(days=16)
    last_last_friday_start = datetime(last_thursday.year, last_thursday.month, last_thursday.day, 16, 0) - timedelta(days=1)
    print("last_last_friday_start" + str(last_last_friday_start))
    if current_datetime.weekday() == 0:
        this_thursday = current_datetime - timedelta(days=4)
    elif current_datetime.weekday() == 1:
        this_thursday = current_datetime - timedelta(days=5)
    elif current_datetime.weekday() == 2:
        this_thursday = current_datetime - timedelta(days=6)
    elif current_datetime.weekday() == 3:
        this_thursday = current_datetime - timedelta(days=7)
    elif current_datetime.weekday() == 4:
        this_thursday = current_datetime - timedelta(days=8)
    elif current_datetime.weekday() == 5:
        this_thursday = current_datetime - timedelta(days=9)
    elif current_datetime.weekday() == 6:
        this_thursday = current_datetime - timedelta(days=10)
    last_thursday_end = datetime(this_thursday.year, this_thursday.month, this_thursday.day, 15, 0)
    print("last_thursday_end" + str(last_thursday_end))
    # </editor-fold>
    # <editor-fold scr='cems计数变量归零'>
    # 检校各厂部
    caironmake = 0
    casteelmake = 0
    castrips = 0
    cahotroll = 0
    cacoldroll = 0
    casiliconsteel = 0
    casteelelectricity = 0
    catransport = 0
    caeaep = 0
    # 启停炉各厂部
    stironmake = 0
    ststeelmake = 0
    ststrips = 0
    sthotroll = 0
    stcoldroll = 0
    stsiliconsteel = 0
    ststeelelectricity = 0
    sttransport = 0
    steaep = 0
    # 工况各厂部
    opironmake = 0
    opsteelmake = 0
    opstrips = 0
    ophotroll = 0
    opcoldroll = 0
    opsiliconsteel = 0
    opsteelelectricity = 0
    optransport = 0
    opeaep = 0
    # 故障各厂部
    erironmake = 0
    ersteelmake = 0
    erstrips = 0
    erhotroll = 0
    ercoldroll = 0
    ersiliconsteel = 0
    ersteelelectricity = 0
    ertransport = 0
    ereaep = 0
    # </editor-fold>
    for row in CEMS_sheet.iloc[1:].itertuples(index=False):
        # print(row[11])
        if last_last_friday_start <= datetime.strptime(row[11],"%Y-%m-%d %H:%M") <= last_thursday_end:
            # print(row[11])
            if '故障' in row[8]:
                if row[3] == IRONMAKE:
                    erironmake += 1
                if row[3] == STEELMAKE:
                    ersteelmake += 1
                if row[3] == STRIPS:
                    erstrips += 1
                if row[3] == HOTROLL:
                    erhotroll += 1
                if row[3] == COLDROLL:
                    ercoldroll += 1
                if row[3] == SILICONSTEEL:
                    ersiliconsteel += 1
                if row[3] == STEELELECTRICITY:
                    ersteelelectricity += 1
                if row[3] == TRANSPORT:
                    ertransport += 1
                if row[3] == EAEP:
                    ereaep += 1
            elif row[0] == CALIBRATION:
                if row[3] == IRONMAKE:
                    caironmake += 1
                if row[3] == STEELMAKE:
                    casteelmake += 1
                if row[3] == STRIPS:
                    castrips += 1
                if row[3] == HOTROLL:
                    cahotroll += 1
                if row[3] == COLDROLL:
                    cacoldroll += 1
                if row[3] == SILICONSTEEL:
                    casiliconsteel += 1
                if row[3] == STEELELECTRICITY:
                    casteelelectricity += 1
                if row[3] == TRANSPORT:
                    catransport += 1
                if row[3] == EAEP:
                    caeaep += 1
            elif row[0] == STOPPAGE:
                if row[3] == IRONMAKE:
                    stironmake += 1
                if row[3] == STEELMAKE:
                    ststeelmake += 1
                if row[3] == STRIPS:
                    ststrips += 1
                if row[3] == HOTROLL:
                    sthotroll += 1
                if row[3] == COLDROLL:
                    stcoldroll += 1
                if row[3] == SILICONSTEEL:
                    stsiliconsteel += 1
                if row[3] == STEELELECTRICITY:
                    ststeelelectricity += 1
                if row[3] == TRANSPORT:
                    sttransport += 1
                if row[3] == EAEP:
                    steaep += 1
            elif row[0] == OPERATECONDITION:
                if row[3] == IRONMAKE:
                    opironmake += 1
                if row[3] == STEELMAKE:
                    opsteelmake += 1
                if row[3] == STRIPS:
                    opstrips += 1
                if row[3] == HOTROLL:
                    ophotroll += 1
                if row[3] == COLDROLL:
                    opcoldroll += 1
                if row[3] == SILICONSTEEL:
                    opsiliconsteel += 1
                if row[3] == STEELELECTRICITY:
                    opsteelelectricity += 1
                if row[3] == TRANSPORT:
                    optransport += 1
                if row[3] == EAEP:
                    opeaep += 1
    # <editor-fold scr='将统计好的数值填入对应位置（上上周到上周）'>
        template_sheet['B4'] = caironmake
        template_sheet['B5'] = casteelmake
        template_sheet['B6'] = castrips
        template_sheet['B7'] = cahotroll
        template_sheet['B8'] = cacoldroll
        template_sheet['B9'] = casiliconsteel
        template_sheet['B10'] = casteelelectricity
        template_sheet['B11'] = catransport
        template_sheet['B12'] = caeaep
        template_sheet['D4'] = stironmake
        template_sheet['D5'] = ststeelmake
        template_sheet['D6'] = ststrips
        template_sheet['D7'] = sthotroll
        template_sheet['D8'] = stcoldroll
        template_sheet['D9'] = stsiliconsteel
        template_sheet['D10'] = ststeelelectricity
        template_sheet['D11'] = sttransport
        template_sheet['D12'] = steaep
        template_sheet['F4'] = opironmake
        template_sheet['F5'] = opsteelmake
        template_sheet['F6'] = opstrips
        template_sheet['F7'] = ophotroll
        template_sheet['F8'] = opcoldroll
        template_sheet['F9'] = opsiliconsteel
        template_sheet['F10'] = opsteelelectricity
        template_sheet['F11'] = optransport
        template_sheet['F12'] = opeaep
        template_sheet['H4'] = erironmake
        template_sheet['H5'] = ersteelmake
        template_sheet['H6'] = erstrips
        template_sheet['H7'] = erhotroll
        template_sheet['H8'] = ercoldroll
        template_sheet['H9'] = ersiliconsteel
        template_sheet['H10'] = ersteelelectricity
        template_sheet['H11'] = ertransport
        template_sheet['H12'] = ereaep
        # </editor-fold>
    # </editor-fold>
    # </editor-fold>

    # <editor-fold scr='统计环保设备数据并填入template表中'>
    GF_sheet = pd.read_excel(ALLALARMSTABLEPATH,sheet_name='治理设备')
    # <editor-fold desc='定义治理设备计数变量'>
    # 未联动各厂部
    ulironmake = 0
    ulsteelmake = 0
    ulstrips = 0
    ulhotroll = 0
    ulcoldroll = 0
    ulsiliconsteel = 0
    ulsteelelectricity = 0
    ultransport = 0
    uleaep = 0
    # 风机电流超限各厂部
    foironmake = 0
    fosteelmake = 0
    fostrips = 0
    fohotroll = 0
    focoldroll = 0
    fosiliconsteel = 0
    fosteelelectricity = 0
    fotransport = 0
    foeaep = 0
    # 压差超限各厂部
    poironmake = 0
    posteelmake = 0
    postrips = 0
    pohotroll = 0
    pocoldroll = 0
    posiliconsteel = 0
    posteelelectricity = 0
    potransport = 0
    poeaep = 0
    # </editor-fold>
    for row in GF_sheet.iloc[1:].itertuples(index=False):
        # print(row[7])
        # print(row[8])
        if last_friday_start <= datetime.strptime(str(row[7]),"%Y-%m-%d %H:%M:%S") <= this_thursday_end:
            if row[4] == UNLINKAGE:
                if row[2] == IRONMAKE:
                    ulironmake += 1
                if row[2] == STEELMAKE:
                    ulsteelmake += 1
                if row[2] == STRIPS:
                    ulstrips += 1
                if row[2] == HOTROLL:
                    ulhotroll += 1
                if row[2] == COLDROLL:
                    ulcoldroll += 1
                if row[2] == SILICONSTEEL:
                    ulsiliconsteel += 1
                if row[2] == STEELELECTRICITY:
                    ulsteelelectricity += 1
                if row[2] == TRANSPORT:
                    ultransport += 1
                if row[2] == EAEP:
                    uleaep += 1
            elif row[4] == FANSCURRENTOVERRUN:
                if row[2] == IRONMAKE:
                    foironmake += 1
                if row[2] == STEELMAKE:
                    fosteelmake += 1
                if row[2] == STRIPS:
                    fostrips += 1
                if row[2] == HOTROLL:
                    fohotroll += 1
                if row[2] == COLDROLL:
                    focoldroll += 1
                if row[2] == SILICONSTEEL:
                    fosiliconsteel += 1
                if row[2] == STEELELECTRICITY:
                    fosteelelectricity += 1
                if row[2] == TRANSPORT:
                    fotransport += 1
                if row[2] == EAEP:
                    foeaep += 1
            elif row[4] == DIFFERENTIALPRESSUREOVERRUN:
                if row[2] == IRONMAKE:
                    poironmake += 1
                if row[2] == STEELMAKE:
                    posteelmake += 1
                if row[2] == STRIPS:
                    postrips += 1
                if row[2] == HOTROLL:
                    pohotroll += 1
                if row[2] == COLDROLL:
                    pocoldroll += 1
                if row[2] == SILICONSTEEL:
                    posiliconsteel += 1
                if row[2] == STEELELECTRICITY:
                    posteelelectricity += 1
                if row[2] == TRANSPORT:
                    potransport += 1
                if row[2] == EAEP:
                    poeaep += 1
    # <editor-fold desc='将统计好的治理设备数值填入对应位置（上周到这一周）'>
    # 未联动开启
    template_sheet['C31'] = ulironmake
    template_sheet['C32'] = ulsteelmake
    template_sheet['C33'] = ulstrips
    template_sheet['C34'] = ulhotroll
    template_sheet['C35'] = ulcoldroll
    template_sheet['C36'] = ulsiliconsteel
    template_sheet['C37'] = ulsteelelectricity
    template_sheet['C38'] = ultransport
    template_sheet['C39'] = uleaep
    # 风机电流超限
    template_sheet['E31'] = foironmake
    template_sheet['E32'] = fosteelmake
    template_sheet['E33'] = fostrips
    template_sheet['E34'] = fohotroll
    template_sheet['E35'] = focoldroll
    template_sheet['E36'] = fosiliconsteel
    template_sheet['E37'] = fosteelelectricity
    template_sheet['E38'] = fotransport
    template_sheet['E39'] = foeaep
    # 压差超限
    template_sheet['G31'] = poironmake
    template_sheet['G32'] = posteelmake
    template_sheet['G33'] = postrips
    template_sheet['G34'] = pohotroll
    template_sheet['G35'] = pocoldroll
    template_sheet['G36'] = posiliconsteel
    template_sheet['G37'] = posteelelectricity
    template_sheet['G38'] = potransport
    template_sheet['G39'] = poeaep
    # </editor-fold>

    # <editor-fold desc='治理设置计数变量归零'>
    # 未联动各厂部
    ulironmake = 0
    ulsteelmake = 0
    ulstrips = 0
    ulhotroll = 0
    ulcoldroll = 0
    ulsiliconsteel = 0
    ulsteelelectricity = 0
    ultransport = 0
    uleaep = 0
    # 风机电流超限各厂部
    foironmake = 0
    fosteelmake = 0
    fostrips = 0
    fohotroll = 0
    focoldroll = 0
    fosiliconsteel = 0
    fosteelelectricity = 0
    fotransport = 0
    foeaep = 0
    # 压差超限各厂部
    poironmake = 0
    posteelmake = 0
    postrips = 0
    pohotroll = 0
    pocoldroll = 0
    posiliconsteel = 0
    posteelelectricity = 0
    potransport = 0
    poeaep = 0
    # </editor-fold>
    for row in GF_sheet.iloc[1:].itertuples(index=False):
        if last_last_friday_start <= datetime.strptime(str(row[7]),"%Y-%m-%d %H:%M:%S") <= last_thursday_end:
            if row[4] == UNLINKAGE:
                if row[2] == IRONMAKE:
                    ulironmake += 1
                if row[2] == STEELMAKE:
                    ulsteelmake += 1
                if row[2] == STRIPS:
                    ulstrips += 1
                if row[2] == HOTROLL:
                    ulhotroll += 1
                if row[2] == COLDROLL:
                    ulcoldroll += 1
                if row[2] == SILICONSTEEL:
                    ulsiliconsteel += 1
                if row[2] == STEELELECTRICITY:
                    ulsteelelectricity += 1
                if row[2] == TRANSPORT:
                    ultransport += 1
                if row[2] == EAEP:
                    uleaep += 1
            elif row[4] == FANSCURRENTOVERRUN:
                if row[2] == IRONMAKE:
                    foironmake += 1
                if row[2] == STEELMAKE:
                    fosteelmake += 1
                if row[2] == STRIPS:
                    fostrips += 1
                if row[2] == HOTROLL:
                    fohotroll += 1
                if row[2] == COLDROLL:
                    focoldroll += 1
                if row[2] == SILICONSTEEL:
                    fosiliconsteel += 1
                if row[2] == STEELELECTRICITY:
                    fosteelelectricity += 1
                if row[2] == TRANSPORT:
                    fotransport += 1
                if row[2] == EAEP:
                    foeaep += 1
            elif row[4] == DIFFERENTIALPRESSUREOVERRUN:
                if row[2] == IRONMAKE:
                    poironmake += 1
                if row[2] == STEELMAKE:
                    posteelmake += 1
                if row[2] == STRIPS:
                    postrips += 1
                if row[2] == HOTROLL:
                    pohotroll += 1
                if row[2] == COLDROLL:
                    pocoldroll += 1
                if row[2] == SILICONSTEEL:
                    posiliconsteel += 1
                if row[2] == STEELELECTRICITY:
                    posteelelectricity += 1
                if row[2] == TRANSPORT:
                    potransport += 1
                if row[2] == EAEP:
                    poeaep += 1
    # <editor-fold desc='将统计好的治理设备数值填入对应位置（上上周到上周）'>
    # 未联动开启
    template_sheet['B31'] = ulironmake
    template_sheet['B32'] = ulsteelmake
    template_sheet['B33'] = ulstrips
    template_sheet['B34'] = ulhotroll
    template_sheet['B35'] = ulcoldroll
    template_sheet['B36'] = ulsiliconsteel
    template_sheet['B37'] = ulsteelelectricity
    template_sheet['B38'] = ultransport
    template_sheet['B39'] = uleaep
    # 风机电流超限
    template_sheet['D31'] = foironmake
    template_sheet['D32'] = fosteelmake
    template_sheet['D33'] = fostrips
    template_sheet['D34'] = fohotroll
    template_sheet['D35'] = focoldroll
    template_sheet['D36'] = fosiliconsteel
    template_sheet['D37'] = fosteelelectricity
    template_sheet['D38'] = fotransport
    template_sheet['D39'] = foeaep
    #压差超限
    template_sheet['F31'] = poironmake
    template_sheet['F32'] = posteelmake
    template_sheet['F33'] = postrips
    template_sheet['F34'] = pohotroll
    template_sheet['F35'] = pocoldroll
    template_sheet['F36'] = posiliconsteel
    template_sheet['F37'] = posteelelectricity
    template_sheet['F38'] = potransport
    template_sheet['F39'] = poeaep
    # </editor-fold>
    # </editor-fold>
    template_workbook.save(OUTPUTFILEPATH)


if __name__ == '__main__':
    main()
