import pandas as pd
import numpy as np
import datetime

DATAFILEPATH = 'D:\\elseFile\\work\\日常工作\\月度超标统计\\2025年年度超标统计.xlsx'

if __name__ == '__main__':
    print(datetime.datetime.now().month)

    data_sheet = pd.read_excel(DATAFILEPATH,header=None)
    data_array = [['超标类型','点位名称','污染因子','时间']]
    for row in data_sheet.iloc[1:].itertuples(index=False):
        # print(row[13])
        if datetime.datetime.strptime(str(row[13]),"%Y-%m-%d %H:%M").month == datetime.datetime.now().month:
            newrow = [row[0],row[2],row[15],row[13]]
            data_array = np.vstack((data_array, newrow))

    # print(data_array)

    today = datetime.date.today()
    oneday = datetime.timedelta(days=1)
    yesterday = today - oneday
    day_array = [['超标类型','点位名称','污染因子','时间']]
    month_array = [['超标类型','点位名称','污染因子','时间']]
    for row in data_array[1:]:
        if datetime.datetime.strptime(row[3], "%Y-%m-%d %H:%M").month == yesterday.month and datetime.datetime.strptime(row[3], "%Y-%m-%d %H:%M").day != today.day:
            month_array = np.vstack((month_array, row))
        if datetime.datetime.strptime(row[3], "%Y-%m-%d %H:%M").day == yesterday.day:
            day_array = np.vstack((day_array, row))
    # 计算昨日达标率
    day_list = []
    for row in day_array[1:]:
        day_list.append(row[1] + " " + row[2])
    day_list = list(set(day_list))
    sum = 248 # 一共248个（点位&因子）
    sum_final = 0
    day_low = 1
    day_low_point_factor = ''
    for point_factor in day_list:
        temp_op = 0
        temp_el = 0
        for row in day_array[1:]:
            if point_factor == row[1] + " " + row[2]:
                if row[0] == '工况':
                    temp_op = temp_op + 1
                else:
                    temp_el = temp_el + 1
        try:
            sum_final = sum_final + (24-temp_op-temp_el)/(24-temp_el)
        except:
            sum_final = sum_final + 1
        sum = sum - 1
        try:
            if (24-temp_op-temp_el)/(24-temp_el) < day_low:
                day_low = (24-temp_op-temp_el)/(24-temp_el)
                day_low_point_factor = point_factor
        except:
            pass
    sum_final = sum_final + sum
    day_rate = sum_final/248
    print("昨日平均达标率为：" + str(day_rate * 100))
    print("昨日最低达标率为：" + str(day_low * 100) + " " + day_low_point_factor)
    # 计算月达标率
    month_list = []
    for row in month_array[1:]:
        month_list.append(row[1] + " " + row[2])
    month_list = list(set(month_list))
    sum = 248  # 一共248个（点位&因子）
    sum_final = 0
    day_low = 1
    day_low_point_factor = ''
    for point_factor in month_list:
        temp_op = 0
        temp_el = 0
        for row in month_array[1:]:
            if point_factor == row[1] + " " + row[2]:
                if row[0] == '工况':
                    temp_op = temp_op + 1
                else:
                    temp_el = temp_el + 1
        sum_final = sum_final + (yesterday.day * 24 - temp_op - temp_el) / (yesterday.day * 24 - temp_el)
        sum = sum - 1
        if (yesterday.day*24-temp_op-temp_el)/(yesterday.day*24-temp_el) < day_low:
            day_low = (yesterday.day*24-temp_op-temp_el)/(yesterday.day*24-temp_el)
            day_low_point_factor = point_factor
    sum_final = sum_final + sum
    day_rate = sum_final / 248
    print("昨日累计达标率为：" + str(day_rate * 100))
    print("昨日累计最低达标率为：" + str(day_low * 100) + " " + day_low_point_factor)
