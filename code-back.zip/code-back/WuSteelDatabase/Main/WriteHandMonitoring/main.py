import pandas as pd
from openpyxl import load_workbook
import numpy as np
import datetime
from pprint import pprint

# <editor-fold desc='文件路径定义'>
TEMPLATE_FILE_PATH = "D:\\OperationForProcess\\2025年手工监测台账.xlsx"
DATA_FILE_PATH = "D:\\OperationForProcess\\2025年总任务表.xlsx"
OUTPUT_FILE_FATH = "D:\\OperationForProcess\\2025年手工监测台账（结果）.xlsx"
# </editor-fold>

# 写有组织废气数据到"有组织（手工）"sheet或者"大气降尘"sheet里面
def gas_write(workbook, hand_array, sheet_name, factor_type, factor_tag):
    sheet_organise_gas = workbook[sheet_name]
    information_array = [['单位名称','排口编号','点位名称','监测因子','监测频次']]
    for row in sheet_organise_gas.iter_rows(min_row=3,max_row=701,min_col=1,max_col=5):
        row_data = []
        for cell in row:
            cell_value = str(cell.value) if cell.value is not None else "" # 将单元格内的内容直接转换为字符串
            row_data.append(cell_value)
        information_array.append(row_data)
    # 简化hand_array
    mask = hand_array[:,0] == factor_type # 返回布尔数组 [True, False, True, False]
    # 使用布尔索引筛选符合条件的行
    filtered_data = hand_array[mask]
    hand_array = filtered_data
    row_position = 3
    January_position = 7
    for row in information_array[1:]:
        for data_row in hand_array:
            if row[factor_tag] == data_row[factor_tag] and row[3] == data_row[3]:
                # print(data_row[7])
                time_str = datetime.datetime.strptime(str(data_row[7]), "%Y-%m-%d %H:%M:%S")
                sheet_organise_gas.cell(row=row_position,column=January_position+time_str.month-1,value=data_row[8])
        row_position = row_position + 1

# 写废水数据到sheet"废水（手工）"或者sheet"雨水"里面
def water_write(workbook, hand_array, sheet_name, pollution_type):
    sheet_waste_water = workbook[sheet_name]
    information_array = [['单位名称','排口编号','点位名称','监测因子','监测频次']]
    for row in sheet_waste_water.iter_rows(min_row=3,max_row=121,min_col=1,max_col=5):
        row_data = []
        for cell in row:
            cell_value = str(cell.value) if cell.value is not None else ""
            row_data.append(cell_value)
        information_array.append(row_data)
    # pprint.pprint(information_array)
    mask = hand_array[:,0] == pollution_type
    filtered_data = hand_array[mask]
    hand_array = filtered_data
    mask = hand_array[:,4] == "手工"
    filtered_data = hand_array[mask]
    hand_array = filtered_data
    mask = hand_array[:,11] == "A"
    filtered_data = hand_array[mask]
    hand_array = filtered_data
    sorted_array = sorted(hand_array,key=lambda x: x[7])
    # print(sorted_array)

    temp_time = sorted_array[1][7]
    date_flag = 0 # 标记是否另起一列填时间
    date_position = 7
    for data in sorted_array[1:]:
        row_position = 3
        if data[7] != temp_time:
            date_flag = 0
            temp_time = data[7]
        if date_flag == 0:
            sheet_waste_water.cell(row=2,column=date_position,value=str(datetime.datetime.strptime(str(data[7]), "%Y-%m-%d %H:%M:%S").month) + "月" + str(datetime.datetime.strptime(str(data[7]), "%Y-%m-%d %H:%M:%S").day) + "日")
            date_flag = 1
            date_position = date_position + 1
        for row in information_array[1:]:
            if row[2] == data[2] and row[3] == data[3]:
                sheet_waste_water.cell(row=row_position,column=date_position-1,value=data[8])
                # print(row_position)
            row_position = row_position + 1

if __name__ == '__main__':
    # 数据读入
    data_sheet = pd.read_excel(DATA_FILE_PATH,sheet_name="监测任务基础数据表",header=None)
    data_sheet.fillna('/',inplace=True)
    hand_array = np.array([['污染类别','排口编号','排口名称','监测因子','监测方式','监测周期','许可限值','监测日期','实测浓度','折算浓度','标杆风量','任务类型']])
    for row in data_sheet.iloc[2:].itertuples(index=False):
        newrow = [row[2],row[3],row[5],row[6],row[7],row[8],row[10],row[14],row[16],row[17],row[18],row[1]]
        hand_array = np.vstack((hand_array,newrow))
    # pprint(hand_array[0])
    # pprint(hand_array[1])

    # 模板读入
    template_file_workbook = load_workbook(TEMPLATE_FILE_PATH)
    gas_write(template_file_workbook, hand_array, "有组织（手工）", "有组织", 1)
    water_write(template_file_workbook, hand_array, "废水（手工）", "废水")
    water_write(template_file_workbook, hand_array, "雨水", "雨水")
    gas_write(template_file_workbook, hand_array, "大气降尘", "大气降尘", 2)

    template_file_workbook.save(OUTPUT_FILE_FATH)
