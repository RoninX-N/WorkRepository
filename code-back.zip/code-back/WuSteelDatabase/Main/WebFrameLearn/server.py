# @app.route('/hello',methods=['GET','POST'],endpoint='hello')
# def hello():
#     return "hello world!"
#
# @app.route('/hi',methods=['POST'],endpoint='hi')
# def hi():
#     return "ok"

# # <editor-fold scr="变量规则">
# from flask import Flask
# app = Flask(__name__)
# # string 接受任何不包含斜杠的文本
# # int 接受正整数
# # float 接受正浮点数
# # path 接受包含斜杠的文本
# @app.route('/user/<id>')# 也可以不传字符串类型，用int类型，route里写'/user/<int:id>'
# def index(id):
#     if id == '1':
#         return 'python'
#     if id == str(2):
#         return 'django'
#     if int(id) == 3:
#         return 'flask'
#     return "hello world"
# if __name__ == '__main__':
#     app.run()
# # </editor-fold>

# # <editor-fold scr="自定义转换器">
# from werkzeug.routing import BaseConverter
# from flask import Flask
#
# app = Flask(__name__)
#
# class RegexConverter(BaseConverter):
#     '''自定义转化器类'''
#     def __init__(self,url_map,regex):
#         # 调用父类的方法
#         super(RegexConverter,self).__init__(url_map)
#         self.regex = regex
#
#     def to_python(self,value):
#         # 父类的方法、功能已经实现好了
#         print('to_python方法已被调用')
#         return value
#
# # 将自定义的转换器类添加到flask应用中
# app.url_map.converters['re'] = RegexConverter
#
# @app.route('/index/<re("1\d{10}"):value>')
# def index(value):
#     print(value)
#     return 'hello'
# if __name__ == '__main__':
#     app.run()
# # </editor-fold>

# <editor-fold scr="form表单">
from flask import Flask,render_template,request
app = Flask(__name__)
# GET是安全的请求，不改变当前页面的内容，POST是不安全的请求，要改变当前的页面，就像登录一样
@app.route('/index',methods=['GET','POST'])
def index():
    # 利用request对象获取前端输入的数据
    if request.method == 'GET':
        return render_template('index.html')
    if request.method == 'POST':
        name = request.form.get('name')
        password = request.form.get('password')
        return 'this is post'

if __name__ == '__main__':
    app.run()
# </eitor-fold>
