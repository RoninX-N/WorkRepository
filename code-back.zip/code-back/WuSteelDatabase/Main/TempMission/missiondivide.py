
import pandas as pd
import numpy as np
from pprint import pprint
import openpyxl

all_mission_file_path = "D:\\elseFile\\work\\Codeworkbench\\ChartTemplate\\（最新）2024计划分解--手工20240125.xlsx"
output_file_path = "D:\\elseFile\\work\\Codeworkbench\\ChartOutPut\\2024总任务表.xlsx"

all_mission_sheet = pd.read_excel(all_mission_file_path,header=None)

lastarray = [["序号","完成单位","计划类别","检测方式","污染类别","项目类别","厂名","排放口编号","监测点位","监测因子","监测频次"]]
# 大遍历，遍历每一行并进行处理
for row in all_mission_sheet.iloc[1:].itertuples(index=False):
    temp_string_array = row[9].split("、")
    if len(temp_string_array) == 1:
        temp_row = [row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10]]
        lastarray = np.vstack((lastarray,temp_row))
    else:
        for factor in temp_string_array:
            temp_row = [row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],factor,row[10]]
            lastarray = np.vstack((lastarray,temp_row))
# 写入输出的excel表
output_workbook = openpyxl.Workbook()
sheet = output_workbook.active

for row_index, row_data in enumerate(lastarray, start=1):
    for col_index, col_data in enumerate(row_data, start=1):
        sheet.cell(row=row_index, column=col_index, value=col_data)

output_workbook.save(output_file_path)

